<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DeviceSwitchController extends Controller
{
    //
}
