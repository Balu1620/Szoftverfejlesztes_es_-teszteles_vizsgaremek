﻿using AdminInterface.Pages;
using AdminInterface.Pages.MotorPages;
using AdminInterface.Pages.SuperAdminPages;
using AdminInterface.Pages.UserPages;
using AdminInterface.Pages.UserPages.DrivingLicenceCheckPages;
using AdminInterface.Pages.UserPages.DrivingLicenceCheckPages.PicturesInLargeCheckDrivingLicencePages;
using AdminInterface.Pages.UserPages.RentalPages;
using AdminInterface.Pages.UserPages.RentalPages.PicturesInLargePages;


namespace AdminInterface
{
    public partial class AppShell : Shell
    {
        protected override void OnAppearing()
        {
            base.OnAppearing();
            this.Title = "  ";
        }
        public AppShell()
        {
            InitializeComponent();
            // Register routes for navigation
            Routing.RegisterRoute(nameof(MainPage), typeof(MainPage));

            //motor
            Routing.RegisterRoute(nameof(AddMotorcyclePage), typeof(AddMotorcyclePage));
            Routing.RegisterRoute(nameof(EditMotorcyclePage), typeof(EditMotorcyclePage));
            Routing.RegisterRoute(nameof(ShowMotorcyclePage), typeof(ShowMotorcyclePage));
            Routing.RegisterRoute(nameof(InServicePage), typeof(InServicePage));
            Routing.RegisterRoute(nameof(NoteProblamMotorcyclePage), typeof(NoteProblamMotorcyclePage));
            Routing.RegisterRoute(nameof(DetailShowMotorcyclePage), typeof(DetailShowMotorcyclePage));

            //users
            Routing.RegisterRoute(nameof(SwitchPage), typeof(SwitchPage));

            Routing.RegisterRoute(nameof(ShowUsersPage), typeof(ShowUsersPage));
            Routing.RegisterRoute(nameof(DetailShowPage), typeof(DetailShowPage));
            Routing.RegisterRoute(nameof(ProblemReporting), typeof(ProblemReporting));
                Routing.RegisterRoute(nameof(FrontDrivingLicenceImage), typeof(FrontDrivingLicenceImage));
                Routing.RegisterRoute(nameof(BackDrivingLicenceImage), typeof(BackDrivingLicenceImage));

            Routing.RegisterRoute(nameof(DetailShowUserCheckPage), typeof(DetailShowUserCheckPage));
            Routing.RegisterRoute(nameof(ShowAllUserPage), typeof(ShowAllUserPage));
                Routing.RegisterRoute(nameof(DrivingLicenceBackImage), typeof(DrivingLicenceBackImage));
                Routing.RegisterRoute(nameof(DrivingLicenceFrontImage), typeof(DrivingLicenceFrontImage));

            //admin
            Routing.RegisterRoute(nameof(ShowAdminsPage), typeof(ShowAdminsPage));
            Routing.RegisterRoute(nameof(LogsShowPage), typeof(LogsShowPage));
            Routing.RegisterRoute(nameof(EditAdminPage), typeof(EditAdminPage));
            Routing.RegisterRoute(nameof(AddAdminPage), typeof(AddAdminPage));
            Routing.RegisterRoute(nameof(DeleteAdminPage), typeof(DeleteAdminPage));


        }
    }
}
