﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminInterface.MotorFilter
{
    //Sa
    public static class MyColor
    {
        public static readonly Color MyRed = Color.FromHex("#f21d1d");
        public static readonly Color MyGreen = Color.FromHex("#458b00");
    }
    internal class AlertExpired : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is DateTime trafficDate && trafficDate < DateTime.Now)
            {
                return MyColor.MyRed;
            }
            return MyColor.MyGreen;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
