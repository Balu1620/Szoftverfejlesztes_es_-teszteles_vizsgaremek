﻿using AdminInterface.Models;
using AdminInterface.Pages.UserPages;
using AdminInterface.Pages.UserPages.DrivingLicenceCheckPages;
using AdminInterface.Pages.UserPages.DrivingLicenceCheckPages.PicturesInLargeCheckDrivingLicencePages;
using AdminInterface.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AdminInterface.ViewModels
{
    [QueryProperty(nameof(CurrentUser), "CurrentUser")]
    [QueryProperty(nameof(LoggedInUser), "LoggedInUser")]
    public partial class UserCheckViewModel : ObservableObject
    {
        [ObservableProperty]
        private List<UserModel> allUserData;

        [ObservableProperty]
        private UserModel currentUser;

        [ObservableProperty]
        private AdminModel loggedInUser;

        [ObservableProperty]
        private bool isLoading;

        private UserApiService UserService;

        public UserCheckViewModel()
        {

            UserService = new UserApiService();
            LoadAdminData();
        }

        private async void LoadAdminData()
        {
            IsLoading = true;
            await Task.Delay(1000);
            AllUserData = await UserService.GetAlluserDataAsync();
            IsLoading = false;
        }


        

        [RelayCommand]
        public async Task ValidationOfTheAuthorizationAsync()
        {
            bool x = await Shell.Current.DisplayAlert("Figyelmeztetés", "Minden adatot megfelelőnek talált?", "Igen", "Nem");
            if (x)
            {
                var updatemotor = new Dictionary<string, object>
                {
                    {"drivingLicenceReal", 1 },
                };
                await UserService.UpdateValidationAsync(CurrentUser.Id, updatemotor, CurrentUser.name, LoggedInUser.Id, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task NavigationToMainPage()
        {
            await Shell.Current.Navigation.PushAsync(new MainPage());
        }

        [RelayCommand]
        public async Task NavigationToSwitchPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(SwitchPage), parameters);
        }

        //Képnegyitás
        [RelayCommand]
        public async Task FrontImageTapped()
        {
            var parameters = new Dictionary<string, object>
            {
                { "CurrentUser", CurrentUser },
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(DrivingLicenceFrontImage), parameters);
        }

        [RelayCommand]
        public async Task BackImageTapped()
        {
            var parameters = new Dictionary<string, object>
            {
                { "CurrentUser", CurrentUser },
                { "LoggedInUser", LoggedInUser}
            };
            await Shell.Current.GoToAsync(nameof(DrivingLicenceBackImage), parameters);
        }

        
        [ObservableProperty]
        private bool isEnable;

        [RelayCommand]
        public async Task NavigationToDetailPage(UserModel infoModel)
        {
            var parameters = new Dictionary<string, object>
            {
                { "CurrentUser", infoModel },
                { "LoggedInUser", LoggedInUser },
                { "IsEnable", IsEnable }
            };

            await Shell.Current.GoToAsync(nameof(DetailShowUserCheckPage), parameters);
        }

        [RelayCommand]
        public async Task NavigationToDetailShowUserCheckPage(UserModel user)
        {
            var parameters = new Dictionary<string, object>
            {
                { "CurrentUser", user },
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(DetailShowUserCheckPage), parameters);
        }

        [ObservableProperty]
        private double rotationAngle;

        [RelayCommand]
        public void RotateImage()
        {
            RotationAngle += 90;
            if (RotationAngle >= 360)
            {
                RotationAngle = 0; // A forgatás 360 fok után visszaáll 0-ra
            }
        }


        [RelayCommand]
        public async Task NavigationToShowAllUserPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(ShowAllUserPage), parameters);
        }

    }
}
