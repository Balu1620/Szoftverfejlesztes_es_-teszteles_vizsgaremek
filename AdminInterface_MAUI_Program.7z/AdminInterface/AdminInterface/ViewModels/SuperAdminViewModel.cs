﻿using AdminInterface.Models;
using AdminInterface.Pages.SuperAdminPages;
using AdminInterface.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Maui.ApplicationModel.Communication;
using System.Text.RegularExpressions;

namespace AdminInterface.ViewModels
{
    [QueryProperty(nameof(LoggedInUser), "LoggedInUser")]
    [QueryProperty(nameof(AllAdminData), "AllAdminData")]
    [QueryProperty(nameof(CurrentUser), "CurrentUser")]

    public partial class SuperAdminViewModel : ObservableObject
    {
        private SuperAdminService AdminAPIService;


        [ObservableProperty]
        private AdminModel loggedInUser;

        [ObservableProperty]
        private AdminModel currentUser;

        [ObservableProperty]
        private List<AdminModel> allAdminData;

        [ObservableProperty]
        private List<AdminModel> filteredAdminData;

        [ObservableProperty]
        private List<AdminModel> deletesAdminData;

        [ObservableProperty]
        private List<AdminModel> logFilteredAdminData;

        [ObservableProperty]
        private List<string> jobStatusType = new List<string>() {"Szuperadmin", "Szerelő", "Recepciós" };  

        [ObservableProperty]
        private string newName;
        [ObservableProperty]
        private string newEmail;
        [ObservableProperty]
        private string newPassword;
        [ObservableProperty]
        private int newJobStatus;

        [ObservableProperty]
        private string currentPassword = "";

        [ObservableProperty]
        private bool isLoading;

        public SuperAdminViewModel()
        {
            AdminAPIService = new SuperAdminService();
            LoadAdminData();
        }


        public async void LoadAdminData()
        {
            IsLoading = true;
            await Task.Delay(3000);
            AllAdminData = await AdminAPIService.GetLogsDataAsync();
            if (AllAdminData != null)
            {
                DeletesAdminData = AllAdminData.Where(admin => admin.deleted_at != null ).ToList();
                FilteredAdminData = AllAdminData.Where(admin => admin.deleted_at == null).ToList();
                LogFilteredAdminData = AllAdminData.Where(admin => admin.Logs.Any()).ToList();
            }
            IsLoading = false;
        }

        [RelayCommand]
        public async Task NavigationToLogsShowPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "AllAdminData", AllAdminData },
                { "LoggedInUser", LoggedInUser },
            };
            await Shell.Current.GoToAsync(nameof(LogsShowPage), parameters);
        }

        [RelayCommand]
        public async Task NavigationToDeleteAdminPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "AllAdminData", AllAdminData },
                { "LoggedInUser", LoggedInUser },
            };
            await Shell.Current.GoToAsync(nameof(DeleteAdminPage), parameters);
        }

        /*Kijelentkezés*/
        [RelayCommand]
        public async Task NavigationToHomePage()
        {
            await Shell.Current.Navigation.PushAsync(new MainPage());
        }

        [RelayCommand]
        public async Task AdminAddAsync()
        {
            bool x = await Shell.Current.DisplayAlert("Adatellenőrzés", "Minden adatot rendben talált? Kérjük, ellenőrizze még egyszer!", "Igen", "Nem");
            if (x)
            {
                if (!string.IsNullOrEmpty(NewName) 
                    && !string.IsNullOrEmpty(NewEmail)
                    && !string.IsNullOrEmpty(NewPassword) 
                    && NewJobStatus != null)
                {
                    bool emailExists = AllAdminData.Any(admin => admin.email.ToLower() == NewEmail.ToLower());

                    bool isValid = Regex.IsMatch(NewEmail, @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", RegexOptions.IgnoreCase);

                    if (!emailExists && isValid)
                    {
                        if (NewPassword.Length > 8 && NewPassword.Any(char.IsLower) && NewPassword.Any(char.IsUpper) 
                            && NewPassword.Any(char.IsDigit) && NewPassword.Any(c => !char.IsLetterOrDigit(c)))
                        {
                            string APasswordHash = BCrypt.Net.BCrypt.HashPassword(NewPassword);

                            var parameters = new Dictionary<string, object>
                            {
                                {"name", NewName},
                                {"email", NewEmail.ToLower()},
                                {"password", APasswordHash},
                                {"jobStatus", NewJobStatus},
                                
                            };
                            await AdminAPIService.AddAdminAsync(parameters, LoggedInUser.Id, LoggedInUser, NewName, NewJobStatus);
                        }
                        else
                        {
                            await Shell.Current.DisplayAlert("Hiba", "A jelszónak legalább 8 karakter hosszúnak kell lennie, és tartalmaznia kell kisbetűt, nagybetűt, számot és speciális karaktert.", "OK");
                        }
                    }
                    else
                    {
                        await Shell.Current.DisplayAlert("Hiba", "Az email cím formátuma nem megfelelő, vagy már létezik ez az email cím.", "OK");
                    }
                }
                else
                {
                    await Shell.Current.DisplayAlert("Hiányzó adatok", "Kérjük, töltse ki az összes mezőt: név, email és jelszó.", "OK");
                }
            }
        }

        [RelayCommand]
        public async Task NavigationToAddAdminPage()
        {
            var parameters = new Dictionary<string, object>
            {
                {"LoggedInUser", LoggedInUser},
            };
            await Shell.Current.GoToAsync(nameof(AddAdminPage), parameters);
        }

        
        [RelayCommand]
        public async Task AdminDelete(AdminModel admin)
        {
            bool x = await Shell.Current.DisplayAlert("Megerősítés", "Biztosan deaktiválni kívánja ezt az admint?", "Igen", "Nem");
            if (x)
            {
                await AdminAPIService.DeleteAdminAsync(admin.Id, LoggedInUser.Id, admin.name, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task AdminreStore(AdminModel admin)
        {
            bool x = await Shell.Current.DisplayAlert("Megerősítés", "Biztosan vissza akarja állítani ezt az admint?", "Igen", "Nem");
            if (x)
            {
                var updatedata = new Dictionary<string, object>
                {
                    
                };
                await AdminAPIService.ReStoreAdminAsync(admin.Id, updatedata, LoggedInUser.Id, admin.name, LoggedInUser);
            }
        }


        [RelayCommand]
        public async Task NavigationToAdminUpdatePage(AdminModel admin)
        {
            var parameters = new Dictionary<string, object>
            {
                {"CurrentUser", admin},
                {"LoggedInUser", LoggedInUser},
            };
            await Shell.Current.GoToAsync(nameof(EditAdminPage), parameters);
        }
        
        
        [RelayCommand]
        public async Task AdminUpdate(AdminModel admin)
        {
            bool x = await Shell.Current.DisplayAlert("Adatellenőrzés", "Minden adatot rendben talált?", "Igen", "Nem");
            if (x)
            {
                if (!string.IsNullOrEmpty(CurrentUser.name) 
                    && !string.IsNullOrEmpty(CurrentUser.email) 
                    && !string.IsNullOrEmpty(CurrentUser.password))
                {
                    bool emailExists = allAdminData.Any(admin => admin.email.ToLower() == CurrentUser.email.ToLower()
                    && admin.Id != CurrentUser.Id);

                    bool isValid = Regex.IsMatch(CurrentUser.email, @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", RegexOptions.IgnoreCase);

                    if (!emailExists && isValid)
                    {
                        if (CurrentUser.password.Length > 8 
                            && CurrentUser.password.Any(char.IsLower) 
                            && CurrentUser.password.Any(char.IsUpper) 
                            && CurrentUser.password.Any(char.IsDigit) 
                            && CurrentUser.password.Any(c => !char.IsLetterOrDigit(c)))
                        {
                            var updatedata = new Dictionary<string, object>();
                            if (CurrentPassword == "")
                            {
                                // CurrentPassword = CurrentUser.password;
                                updatedata = new Dictionary<string, object>
                                {
                                    {"name", CurrentUser.name},
                                    {"email", CurrentUser.email},
                                    {"password", CurrentUser.password},
                                    {"jobStatus", CurrentUser.jobStatus},
                                };
                            }
                            else
                            {
                                string UPasswordHash = BCrypt.Net.BCrypt.HashPassword(CurrentPassword);
                                updatedata = new Dictionary<string, object>
                                {
                                    {"name", CurrentUser.name},
                                    {"email", CurrentUser.email},
                                    {"password", UPasswordHash},
                                    {"jobStatus", CurrentUser.jobStatus},
                                };
                            }
                            await AdminAPIService.UpdateAdminAsync(CurrentUser.Id, updatedata, LoggedInUser.Id, CurrentUser.name, LoggedInUser);
                        }
                        else
                        {
                            await Shell.Current.DisplayAlert("Hiba", "A jelszónak legalább 8 karakter hosszúnak kell lennie, és tartalmaznia kell kisbetűt, nagybetűt, számot és speciális karaktert.", "OK");
                        }
                    }
                    else
                    {
                        await Shell.Current.DisplayAlert("Hiba", "Az email cím formátuma nem megfelelő, vagy már létezik ez az email cím.", "OK");
                    }
                }
                else
                {
                    await Shell.Current.DisplayAlert("Hiányzó adatok", "Kérjük, töltse ki az összes mezőt: név, email és jelszó.", "OK");
                }
            }
        }

        [RelayCommand]
        public async Task NavigationToAllAdminPage()
        {
            var parameters = new Dictionary<string, object>
            {
                {"LoggedInUser", LoggedInUser},
            };
            await Shell.Current.GoToAsync(nameof(ShowAdminsPage), parameters);
        }
    }
}
