﻿using AdminInterface.Models;
using AdminInterface.Pages.MotorPages;
using AdminInterface.Pages.SuperAdminPages;
using AdminInterface.Pages.UserPages;
using AdminInterface.Pages.UserPages.DrivingLicenceCheckPages;
using AdminInterface.Pages.UserPages.RentalPages;
using AdminInterface.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;

namespace AdminInterface.ViewModels
{
    [QueryProperty(nameof(LoggedInUser), "LoggedInUser")]
    internal partial class AdminViewModel : ObservableObject
    {
        private SuperAdminService AdminAPIService;
        private AdminService AdminService;


        [ObservableProperty]
        private AdminModel loggedInUser = null;

        [ObservableProperty]
        private bool loggedInMainPage = false;

        [ObservableProperty]
        private List<AdminModel> admins;

        
        private string emailInput;
        public string EmailInput
        {
            get => emailInput;
            set
            {
                emailInput = value;
                OnPropertyChanged();
                FilterSuggestions();
            }
        }

        [ObservableProperty]
        private string passwordInput;

        [ObservableProperty]
        private bool isPassword = true;



        //-------------------------------------------------

        private string selectedSuggestion;
        public string SelectedSuggestion
        {
            get => selectedSuggestion;
            set
            {
                if (selectedSuggestion != value)
                {
                    selectedSuggestion = value;
                    OnPropertyChanged();

                    if (!string.IsNullOrEmpty(selectedSuggestion))
                    {
                        EmailInput = selectedSuggestion;
                        Suggestions.Clear();
                    }
                }
            }
        }


        //-------------------------------------------------

        public ObservableCollection<AdminModel> Adminslist { get; set; } = new();
        public ObservableCollection<LogModel> Logslist { get; set; } = new();
        public ObservableCollection<string> Suggestions { get; set; } = new ObservableCollection<string>();

        private List<string> AllItems = new List<string>();
        public AdminViewModel()
        {
            
            Admins = new List<AdminModel>();
            AdminAPIService = new SuperAdminService();
            AdminService = new AdminService();
            LoadAdmin();
            FilterSuggestions();
        }
       

        //-------------------------------------------------

        [RelayCommand]
        private async Task VisiblePassword()
        {
            if (IsPassword)
            {
                IsPassword = false;
            }
            else
            {
                IsPassword = true;
            }
        }
        //-------------------------------------------------
        
        private void FilterSuggestions()
        {
            var filtered = AllItems.Where(item => !string.IsNullOrWhiteSpace(EmailInput) 
            && item.StartsWith(EmailInput, StringComparison.OrdinalIgnoreCase)).ToList();

            Suggestions.Clear();
            foreach (var item in filtered)
            {
                Suggestions.Add(item);
            }
        }

        //-------------------------------------------------

        //Load Admin
        private async Task LoadAdmin()
        {
            Admins = await AdminAPIService.GetLogsDataAsync();
            if (Admins.Count == 0)
            {
                string name = "Teszt Elek";
                string email = "teszt@gmail.com";
                string password = "Password";
                int jobStatus = 0;
                List<LogModel> Logs = new List<LogModel>();

                string APasswordHash = BCrypt.Net.BCrypt.HashPassword(password);

                var parameters = new Dictionary<string, object>
                {
                    {"name", name},
                    {"email", email},
                    {"password", APasswordHash},
                    {"jobStatus", jobStatus},
                };

                await AdminService.AddAdminIntoDatabaseAsync(parameters, jobStatus);
                Admins = await AdminAPIService.GetLogsDataAsync();
            }
            AllItems = Admins.Select(admin => admin.email).ToList();
        }
        
        [RelayCommand]
        public async Task LoginAsync()
        {
            bool goodPair = false;

            foreach (AdminModel admin in Admins)
            {
                if (admin.email == EmailInput.ToLower() 
                    && BCrypt.Net.BCrypt.Verify(PasswordInput, admin.password) 
                    && admin.deleted_at == null)
                {
                    LoggedInUser = admin;
                    goodPair = true;
                    if (admin.jobStatus == 0)
                    {
                        var parameters = new Dictionary<string, object>
                        {
                            { "LoggedInUser", admin }
                        };
                        await Shell.Current.GoToAsync(nameof(ShowAdminsPage), parameters);
                    }
                    else if (admin.jobStatus == 1)
                    {
                        var parameters = new Dictionary<string, object>
                        {
                            { "LoggedInUser", LoggedInUser }
                        };
                        await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
                    }
                    else if (admin.jobStatus == 2)
                    {
                        var parameters = new Dictionary<string, object>
                        {
                            { "LoggedInUser", LoggedInUser }
                        };
                        await Shell.Current.GoToAsync(nameof(SwitchPage), parameters);
                    }
                }
            }
            if (goodPair == false)
            {
                await Shell.Current.DisplayAlert("Hiba", "Rossz Jelszó-Email Páros", "OK");
            }
        }


        [RelayCommand]
        public async Task NavigationToRentalPages()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(ShowUsersPage), parameters);
        }

        [RelayCommand]
        public async Task NavigationToDrivingCheckPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(ShowAllUserPage), parameters);
        }


        [RelayCommand]
        public async Task NavigationToMainPage()
        {
            await Shell.Current.Navigation.PushAsync(new MainPage());
        }





    }
}
