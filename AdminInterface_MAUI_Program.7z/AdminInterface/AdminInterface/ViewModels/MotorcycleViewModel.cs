﻿using AdminInterface.Models;
using AdminInterface.Pages.MotorPages;
using AdminInterface.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AdminInterface.ViewModels
{
    [QueryProperty(nameof(LoggedInUser), "LoggedInUser")]
    [QueryProperty(nameof(SelectMotorData), "SelectMotorData")]
    public partial class MotorcycleViewModel : ObservableObject
    {
        private MotorcycleService services;

        [ObservableProperty]
        private List<MotorcyclesModel> allMotorcycle;

        [ObservableProperty]
        private List<MotorcyclesModel> allInServicesMotorcycle;

        [ObservableProperty]
        private List<string> gearBoxType = new List<string>() { "Automata", "Manualis (6 fokozatu)", "Manualis (5 fokozatu)", "Manualis (4 fokozatu)" };
        [ObservableProperty]
        private List<string> fuleType = new List<string>() { "E", "B" };
        [ObservableProperty]
        private List<string> drivingLicenceType = new List<string>() { "A2", "A1/B" };
        [ObservableProperty]
        private List<string> locationType = new List<string>()
        {
            "1012 Budapest, Logodi utca 34.",
            "1021 Budapest, Hűvösvölgyi út 136.",
            "1037 Budapest, Bojtár utca 43.",
            "1044 Budapest, Megyeri út 20.",
            "1051 Budapest, Bajcsy-Zsilinszky út 24.",
            "1064 Budapest, Podmaniczky utca 63.",
            "1077 Budapest, Rottenbiller utca 25.",
            "1087 Budapest, Könyves Kálmán körút 52.",
            "1096 Budapest, Haller utca 89.",
            "1103 Budapest, Gyömrői út 50.",
            "1117 Budapest, Szerémi út 67.",
            "1126 Budapest, Böszörményi út 38.",
            "1138 Budapest, Váci út 152.",
            "1148 Budapest, Fogarasi út 45.",
            "1151 Budapest, Károlyi Sándor út 76.",
            "1161 Budapest, Rákosi út 88.",
            "1173 Budapest, Pesti út 237.",
            "1185 Budapest, Üllői út 780.",
            "1195 Budapest, Ady Endre út 134.",
            "1205 Budapest, Kossuth Lajos utca 120.",
            "1211 Budapest, Szállító utca 6.",
            "1223 Budapest, Nagytétényi út 190.",
            "1239 Budapest, Haraszti út 42."
        };

        [ObservableProperty]
        private string newImageName;
        [ObservableProperty]
        private Stream imageStream;
        [ObservableProperty]
        private ImageSource imagePreview;
        [ObservableProperty]
        public string imagePath;

        [ObservableProperty]
        private string newBrand;
        [ObservableProperty]
        private string newType;
        [ObservableProperty]
        private string newLicencePlate;
        [ObservableProperty]
        private string newYear;
        [ObservableProperty]
        private string newGearbox;
        [ObservableProperty]
        private string newFuel;
        [ObservableProperty]
        private string newPowerLE;
        [ObservableProperty]
        private string newPowerkW;
        [ObservableProperty]
        private string newEngineSize;
        [ObservableProperty]
        private string newDrivingLicence;
        [ObservableProperty]
        private string newPlaces;
        [ObservableProperty]
        private string newPrice;
        [ObservableProperty]
        private string newDeposit;
        [ObservableProperty]
        private string newTrafficDate;
        [ObservableProperty]
        private string newLocation;

        [ObservableProperty]
        private MotorcyclesModel selectMotorData;

        [ObservableProperty]
        private string noteMotorText;
  
        //-----------------------

        [ObservableProperty]
        private AdminModel loggedInUser;

        //----------------------

        [ObservableProperty]
        private bool isLoading;

        //----------------------

        [ObservableProperty]
        private bool hasNullComment;

        public MotorcycleViewModel()
        {
            services = new MotorcycleService();
            //adminService = new AdminService();
            LoadMotorAsync();
            //dbContext = new AppDbContext();
        }



        private async void LoadMotorAsync()
        {
            IsLoading = true;
            await Task.Delay(1000);
            AllMotorcycle = await services.GetAllMotorDataAsync();
            AllInServicesMotorcycle = await services.GetAllInServiceMotorDataAsync();
            IsLoading = false;
        }

        public bool IsNumber(string text)
        {
            return text.All(char.IsDigit);
        }

        [RelayCommand]
        public async Task MotorAddAsync()
        {
            bool x = await Shell.Current.DisplayAlert("Adatellenőrzés", "Minden adatot rendben talált?", "Igen", "Nem");
            if (x)
            {
                int year = 0; float Le = 0; float kW = 0; float engine = 0; int place = 0; int price = 0; int deposit = 0; DateTime date = DateTime.Now.Date; NewTrafficDate = date.ToString("yyyy.MM.dd.");

                if (!string.IsNullOrEmpty(NewBrand) && !string.IsNullOrEmpty(NewType) && !string.IsNullOrEmpty(NewLicencePlate)
                && !string.IsNullOrEmpty(NewYear) && !string.IsNullOrEmpty(NewGearbox) && !string.IsNullOrEmpty(NewFuel)
                && !string.IsNullOrEmpty(NewPowerLE) && !string.IsNullOrEmpty(NewPowerkW) && !string.IsNullOrEmpty(NewEngineSize)
                && !string.IsNullOrEmpty(NewDrivingLicence) && !string.IsNullOrEmpty(NewPlaces) && !string.IsNullOrEmpty(NewPrice)
                && !string.IsNullOrEmpty(NewDeposit) && !string.IsNullOrEmpty(NewTrafficDate) && !string.IsNullOrEmpty(NewLocation))
                {
                    if (int.TryParse(NewYear, out year) && float.TryParse(NewPowerLE, out Le) && float.TryParse(NewPowerkW, out kW) 
                        && float.TryParse(NewEngineSize, out engine) && int.TryParse(NewPlaces, out place) && int.TryParse(NewPrice, out price)
                        && int.TryParse(NewDeposit, out deposit) && DateTime.TryParse(NewTrafficDate, out date))
                    {
                        if (year <= DateTime.Now.Year && year >= 1800)
                        {
                            bool isValid = Regex.IsMatch(NewLicencePlate, @"^[A-Z]{3}\-[0-9]{3}$", RegexOptions.IgnoreCase);
                            if (isValid)
                            {
                                string nowdate = date.ToString("yyyy.MM.dd.");

                                var addmotor = new Dictionary<string, object>
                                {
                                    {"brand", NewBrand},
                                    {"type", NewType},
                                    {"licencePlate", NewLicencePlate},
                                    {"year", year},
                                    {"gearbox", NewGearbox},
                                    {"fuel", NewFuel},
                                    {"powerLe", Le.ToString(CultureInfo.InvariantCulture)},
                                    {"powerkW", kW.ToString(CultureInfo.InvariantCulture)},
                                    {"engineSize", engine},
                                    {"drivingLicence", NewDrivingLicence},
                                    {"places", place},
                                    {"price", price},
                                    {"deposit", deposit},
                                    {"trafficDate", nowdate},
                                    {"location", NewLocation},
                                    {"image", NewImageName},
                                    {"isInService", 0},
                                    {"problamComment", ""}
                                };
                                await services.AddMotorAsync(addmotor, NewBrand, NewType, LoggedInUser.Id, LoggedInUser, ImagePath);

                                var parameters = new Dictionary<string, object>
                                {
                                    { "LoggedInUser", LoggedInUser }
                                };
                                await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
                            }
                            else
                            {
                                await Shell.Current.DisplayAlert("Hiba", "A rendszám formátuma nem megfelelő. Kérlek, ellenőrizd újra.", "OK");
                            }
                        }
                        else
                        {
                            await Shell.Current.DisplayAlert("Hiba", "Az évszám nem érvényes. Kérlek, adj meg egy helyes évet.", "OK");
                        }
                    }
                    else
                    {
                        await Shell.Current.DisplayAlert("Hiba", "Valamelyik számformátum hibás. Kérlek, ellenőrizd a számokat.", "OK");
                    }
                }
                else
                {
                    await Shell.Current.DisplayAlert("Hiba", "Kérlek, töltsd ki az összes mezőt.", "OK");
                }                
            }
        }

        [RelayCommand]
        public async Task MotorDelete(MotorcyclesModel motorcycles)
        {
            bool x = await Shell.Current.DisplayAlert("Törlés megerősítése", "Biztosan törölni kívánja ezt a motort?", "Igen", "Nem");
            if (x)
            {
                await services.DeleteMotorAsync(motorcycles.Id, motorcycles.brand, motorcycles.type, LoggedInUser.Id, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task MotorEditProblam(MotorcyclesModel motorcycles)
        {
            var updatemotor = new Dictionary<string, object>
            {
                {"problamComment", motorcycles.problamComment},
                {"LoggedInUser", LoggedInUser}
            };
            await services.UpdateMotorAsync(SelectMotorData.Id, updatemotor, LoggedInUser.Id, SelectMotorData.Id, SelectMotorData.type, LoggedInUser);
        }

        [RelayCommand]
        async void NavigateToDetailEditMotorPage(MotorcyclesModel motor)
        {
            var parameters = new Dictionary<string, object>
            {
                {"SelectMotorData", motor },
                {"LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(EditMotorcyclePage), parameters);
        }

        [RelayCommand]
        public async Task MotorEditAsync()
        {
            bool x = await Shell.Current.DisplayAlert("Figyelmeztetés", "Minden adatot rendben talált?", "Igen", "Nem");
            if (x)
            {
                int year = 0; float Le = 0; float kW = 0; float engine = 0; int place = 0; int price = 0; int deposit = 0; DateTime date = DateTime.Now.Date;
                if (!string.IsNullOrEmpty(SelectMotorData.brand) && !string.IsNullOrEmpty(SelectMotorData.type) && !string.IsNullOrEmpty(SelectMotorData.licencePlate)
                && !string.IsNullOrEmpty(SelectMotorData.gearbox) && !string.IsNullOrEmpty(SelectMotorData.drivingLicence) && !string.IsNullOrEmpty(SelectMotorData.location))
                {
                    string yearString = SelectMotorData.year.ToString();
                    string powerLeString = SelectMotorData.powerLe.ToString();
                    string powerKwString = SelectMotorData.powerkW.ToString();
                    string engineString = SelectMotorData.engineSize.ToString();
                    string placeString = SelectMotorData.places.ToString();
                    string priceString = SelectMotorData.price.ToString();
                    string depositString = SelectMotorData.deposit.ToString();
                    string dateString = SelectMotorData.trafficDate.ToString("yyyy.MM.dd.");

                    if (int.TryParse(yearString, out year) && float.TryParse(powerLeString, out Le) && float.TryParse(powerKwString, out kW)
                        && float.TryParse(engineString, out engine) && int.TryParse(placeString, out place) && int.TryParse(priceString, out price)
                        && int.TryParse(depositString, out deposit) && DateTime.TryParse(dateString, out date))
                    {
                        if (SelectMotorData.year <= DateTime.Now.Year && SelectMotorData.year >= 1800)
                        {
                            bool isValid = Regex.IsMatch(SelectMotorData.licencePlate, @"^[A-Z]{3}\-[0-9]{3}$", RegexOptions.IgnoreCase);
                            if (isValid)
                            {
                                bool isValidDate = (date >= DateTime.Now);

                                if (isValidDate)
                                {
                                    string nowdate = date.ToString("yyyy.MM.dd.");

                                    if (SelectMotorData != null)
                                    {
                                        var updatemotor = new Dictionary<string, object>
                                        {
                                            {"brand", SelectMotorData.brand},
                                            {"type", SelectMotorData.type},
                                            {"licencePlate", SelectMotorData.licencePlate},
                                            {"year", year},
                                            {"gearbox", SelectMotorData.gearbox},
                                            {"fuel", SelectMotorData.fuel},
                                            {"powerLe", Le.ToString(CultureInfo.InvariantCulture)},
                                            {"powerkW", kW.ToString(CultureInfo.InvariantCulture)},
                                            {"engineSize", engine},
                                            {"drivingLicence", SelectMotorData.drivingLicence},
                                            {"places", place},
                                            {"price", price},
                                            {"deposit", deposit},
                                            {"trafficDate", nowdate},
                                            {"location", SelectMotorData.location},
                                        };
                                        await services.UpdateMotorAsync(SelectMotorData.Id, updatemotor, LoggedInUser.Id, SelectMotorData.Id, SelectMotorData.type, LoggedInUser);
                                    }
                                    else
                                    {
                                        await Shell.Current.DisplayAlert("Hiba", "Valamilyik mezőt üresen hagyott", "OK");
                                    }
                                }
                                else
                                {
                                    await Shell.Current.DisplayAlert("Hiba", "Ne adjon meg régebbi dátumot", "OK");
                                }
                            }
                            else
                            {
                                await Shell.Current.DisplayAlert("Hiba", "A rendszám formátuma nem megfelelő. Kérlek, ellenőrizd újra.", "OK");
                            }
                        }
                        else
                        {
                            await Shell.Current.DisplayAlert("Hiba", "Az évszám nem érvényes. Kérlek, adj meg egy helyes évet.", "OK");
                        }
                    }
                    else
                    {
                        await Shell.Current.DisplayAlert("Hiba", "Kérlek, töltsd ki az összes mezőt.", "OK");
                    }
                }
                else
                {
                    await Shell.Current.DisplayAlert("Hiba", "Kérlek, töltsd ki az összes mezőt.", "OK");
                }
            }
        }

        [RelayCommand]
        public async Task NavigationToAddMotorPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(AddMotorcyclePage), parameters);
        }

        [RelayCommand]
        public async Task NavigationToMainPage()
        {
            await Shell.Current.Navigation.PushAsync(new MainPage());
        }

        [RelayCommand]
        public async Task NavigationToBackShowMotor()
        {
            var parameters = new Dictionary<string, object>
            {
                {"LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
        }

        // Kész 
        [RelayCommand]
        public async Task MotorToServicing(MotorcyclesModel motor)
        {
            bool x = await Shell.Current.DisplayAlert("Szervizellenőrzés", "A motor szervizelésre szorul?", "Igen", "Nem");
            if (x)
            {
                var parameters = new Dictionary<string, object>
                {
                    { "LoggedInUser", LoggedInUser },
                    { "isInService", 1 },
                };
                await services.UpdateServiceMotorAsync(motor.Id, parameters, LoggedInUser.Id, motor.type, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task NavigateToInServicesMotorPage()
        {
            var parameters = new Dictionary<string, object>
            {
                {"LoggedInUser", LoggedInUser },
            };
            await Shell.Current.GoToAsync(nameof(InServicePage), parameters);
        }

        // Kész 
        [RelayCommand]
        public async Task MotorToFleetAsync(MotorcyclesModel motor)
        {
            bool x = await Shell.Current.DisplayAlert("Visszaállítás a flottába", "Biztosan vissza szeretné helyezni a motort a flottába?", "Igen", "Nem");
            if (x)
            {
                var parameters = new Dictionary<string, object>
                {
                    { "LoggedInUser", LoggedInUser },
                    { "isInService", 0 },
                    { "problamComment" , SelectMotorData.problamComment }
                };
                await services.UpdateOutServiceMotorAsync(motor.Id, parameters, LoggedInUser.Id, motor.type, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task NavigationToNoteMotorcyclePage(MotorcyclesModel motor)
        {
            var parameters = new Dictionary<string, object>
            {
                {"LoggedInUser", LoggedInUser },
                {"SelectMotorData", motor }
            };
            await Shell.Current.GoToAsync(nameof(NoteProblamMotorcyclePage), parameters);
        }

        [RelayCommand]
        public async Task NavigationToDetailShowMotorcyclePage(MotorcyclesModel motor)
        {
            var parameters = new Dictionary<string, object>
            {
                {"LoggedInUser", LoggedInUser },
                {"SelectMotorData", motor }
            };
            await Shell.Current.GoToAsync(nameof(DetailShowMotorcyclePage), parameters);
        }


        //Kép

        [RelayCommand]
        public async Task PickImageAsync()
        {
            try
            {
                var result = await FilePicker.PickAsync(new PickOptions
                {
                    PickerTitle = "Válassz egy képet",
                    FileTypes = FilePickerFileType.Images
                });

                if (result != null)
                {
                    // Eredeti fájl stream
                    var originalStream = await result.OpenReadAsync();

                    // Lokális elérési út beállítása (alkalmazás saját mappájába)
                    var documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                    NewImageName = result.FileName;
                    ImagePath = Path.Combine(documentsPath, NewImageName);

                    // A fájlt bemásoljuk a lokális mappába (ha még nem létezik, vagy felülírjuk)
                    using (var fileStream = new FileStream(ImagePath, FileMode.Create, FileAccess.Write))
                    {
                        await originalStream.CopyToAsync(fileStream);
                    }

                    // A stream újranyitása a kép előnézethez (mert az előző stream már "elfogyott")
                    ImagePreview = ImageSource.FromFile(ImagePath);
                }
            }
            catch (Exception ex)
            {
                await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült képet választani: {ex.Message}", "OK");
            }
        }

        

    }
}
