﻿using AdminInterface.Models;
using AdminInterface.Pages.UserPages;
using AdminInterface.Pages.UserPages.RentalPages;
using AdminInterface.Pages.UserPages.RentalPages.PicturesInLargePages;
using AdminInterface.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AdminInterface.ViewModels
{
    [QueryProperty(nameof(ShowUser), "ShowUser")]
    [QueryProperty(nameof(LoggedInUser), "LoggedInUser")]
    [QueryProperty(nameof(IsEnable), "IsEnable")]
    public partial class UserViewModel : ObservableObject
    {
        private UserApiService _apiService;

        [ObservableProperty]
        private List<UserLoanInfoModel> alldata;

        [ObservableProperty]
        private UserLoanInfoModel showUser;

        [ObservableProperty]
        private List<string> locationType = new List<string>()
        {
            "1012 Budapest, Logodi utca 34.",
            "1021 Budapest, Hűvösvölgyi út 136.",
            "1037 Budapest, Bojtár utca 43.",
            "1044 Budapest, Megyeri út 20.",
            "1051 Budapest, Bajcsy-Zsilinszky út 24.",
            "1064 Budapest, Podmaniczky utca 63.",
            "1077 Budapest, Rottenbiller utca 25.",
            "1087 Budapest, Könyves Kálmán körút 52.",
            "1096 Budapest, Haller utca 89.",
            "1103 Budapest, Gyömrői út 50.",
            "1117 Budapest, Szerémi út 67.",
            "1126 Budapest, Böszörményi út 38.",
            "1138 Budapest, Váci út 152.",
            "1148 Budapest, Fogarasi út 45.",
            "1151 Budapest, Károlyi Sándor út 76.",
            "1161 Budapest, Rákosi út 88.",
            "1173 Budapest, Pesti út 237.",
            "1185 Budapest, Üllői út 780.",
            "1195 Budapest, Ady Endre út 134.",
            "1205 Budapest, Kossuth Lajos utca 120.",
            "1211 Budapest, Szállító utca 6.",
            "1223 Budapest, Nagytétényi út 190.",
            "1239 Budapest, Haraszti út 42."
        };

        [ObservableProperty]
        private string newLocation;

        [ObservableProperty]
        private string newProblam;

        [ObservableProperty]
        private AdminModel loggedInUser;

        [ObservableProperty]
        private bool isLoading;

        [ObservableProperty]
        private bool isEnable;

        


        //------------------
        public UserViewModel()
        {
            _apiService = new UserApiService();
            LoadUser();
            
        }

        private async void LoadUser()
        {
            IsLoading = true;
            await Task.Delay(1000);
            Alldata = await _apiService.GetDataAsync();
            IsLoading = false;
        }

        [RelayCommand]
        public async Task detailpage(UserLoanInfoModel infoModel)
        {
            bool isEnableTemp = !string.IsNullOrEmpty(infoModel.location);

            // Csak akkor frissítjük, ha változott az érték
            if (IsEnable != isEnableTemp)
            {
                IsEnable = isEnableTemp;
            }

            var parameters = new Dictionary<string, object>
            {
                { "ShowUser", infoModel },
                { "LoggedInUser", LoggedInUser },
                { "IsEnable", IsEnable }
            };

            await Shell.Current.GoToAsync(nameof(DetailShowPage), parameters);
        }

        [RelayCommand]
        public async Task RetrieveAsync()
        {
            bool x = await Shell.Current.DisplayAlert("Állapotellenőrzés", "Minden rendben volt a motor működésével?", "Igen", "Nem");
            if (x)
            {
                if (!string.IsNullOrEmpty(NewProblam))
                {
                    NewProblam = $"{ShowUser.problamComment} \r\r {NewProblam}";
                }
                else
                {
                    NewProblam = ShowUser.problamComment;
                }

                if (string.IsNullOrEmpty(NewLocation))
                {
                    NewLocation = "1012 Budapest, Logodi utca 34.";
                }

                var updatemotor = new Dictionary<string, object>
                {
                    {"location", NewLocation },
                    {"problamComment", NewProblam },
                    {"gaveDown", 1 }
                };
                await _apiService.UpdateRetrieveMotorAsync(ShowUser.Id, ShowUser.motorId, updatemotor, LoggedInUser.Id, NewProblam, ShowUser.brand, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task NavigationToBackShowUsersLoans()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser}
            };
            await Shell.Current.GoToAsync(nameof(ShowUsersPage), parameters); //Itt tartok
        }

        [RelayCommand]
        public async Task TakenFromAsync()
        {
            bool x = await Shell.Current.DisplayAlert("Figyelmeztetés", "Érvényes és rendben van a jogosítvány?", "Igen", "Nem");
            if (x)
            {
                var updatemotor = new Dictionary<string, object>
                {
                    { "location", null },
                    { "LoggedInUser", LoggedInUser}
                };
                    //TODO Csak egyszer jelenjen meg
                await _apiService.TakenFromMotorAsync(ShowUser.motorId, updatemotor, LoggedInUser.Id, ShowUser.type, ShowUser.brand, ShowUser.name, LoggedInUser);
            }
        }

        [RelayCommand]
        public async Task GotoRetrieveAsync()
        {
            var parameters = new Dictionary<string, object>
            {
                { "ShowUser", ShowUser },
                { "LoggedInUser", LoggedInUser}
            };
            await Shell.Current.GoToAsync(nameof(ProblemReporting), parameters);
        }

        [RelayCommand]
        public async Task DeleteRental(UserLoanInfoModel model)
        {
            bool x = await Shell.Current.DisplayAlert("Megerősítés", "Biztosan törölni kívánja ezt a bérlést?", "Igen", "Nem");
            if (x)
            {
                var parameters = new Dictionary<string, object>
                {
                    { "ShowUser", model },
                    { "LoggedInUser", LoggedInUser}
                };
                await _apiService.DeleteRentalAsync(model.Id, model.orders_id, LoggedInUser.Id, LoggedInUser);
            }
        }
        

        //Kijelentkezés
        [RelayCommand]
        public async Task NavigationToMainPage()
        {
            await Shell.Current.Navigation.PushAsync(new MainPage());
        }

        [RelayCommand]
        public async Task NavigationToSwitchPage()
        {
            var parameters = new Dictionary<string, object>
            {
                { "LoggedInUser", LoggedInUser }
            };
            await Shell.Current.GoToAsync(nameof(SwitchPage), parameters);
        }


        //Képnegyitás
        [RelayCommand]
        public async Task FrontImageTapped()
        {
            var parameters = new Dictionary<string, object>
            {
                { "ShowUser", ShowUser },
                { "LoggedInUser", LoggedInUser}
            };
            await Shell.Current.GoToAsync(nameof(FrontDrivingLicenceImage), parameters);
        }

        [RelayCommand]
        public async Task BackImageTapped()
        {
            var parameters = new Dictionary<string, object>
            {
                { "ShowUser", ShowUser },
                { "LoggedInUser", LoggedInUser}
            };
            await Shell.Current.GoToAsync(nameof(BackDrivingLicenceImage), parameters);
        }

        [RelayCommand]
        public async Task Backdetailpage()
        {
            await Shell.Current.Navigation.PopAsync();
        }


        [ObservableProperty]
        private double rotationAngle;

        [RelayCommand]
        public void RotateImage()
        {
            RotationAngle += 90;
            if (RotationAngle >= 360)
            {
                RotationAngle = 0; // A forgatás 360 fok után visszaáll 0-ra
            }
        }




    }
}
