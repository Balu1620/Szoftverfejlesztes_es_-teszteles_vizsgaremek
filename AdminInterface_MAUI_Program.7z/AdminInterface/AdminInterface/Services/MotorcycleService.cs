﻿using AdminInterface.Models;
using AdminInterface.Pages.MotorPages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Text;

namespace AdminInterface.Services
{
    public class MotorcycleService
    {
        private readonly HttpClient _httpClient;
        private AdminService adminService;


        public MotorcycleService()
        {
            adminService = new AdminService();
            _httpClient = new HttpClient();
        }


        // Get all motor data
        public async Task<List<MotorcyclesModel>> GetAllMotorDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("http://127.0.0.1:8000/api/allMotors");

                var jsonObject = JObject.Parse(response);
                var motorList = new List<MotorcyclesModel>();

                if (jsonObject["motors"] is JArray loansArray)
                {
                    foreach (var item in loansArray)
                    {
                        if (item["isInService"].Value<bool>() == false)
                        {
                            var motor = new MotorcyclesModel
                            {
                                Id = item["id"].Value<int>(),
                                brand = item["brand"].ToString(),
                                type = item["type"].ToString(),
                                licencePlate = item["licencePlate"].ToString(),
                                year = item["year"].Value<int>(),
                                gearbox = item["gearbox"].ToString(),
                                fuel = item["fuel"].ToString(),
                                powerLe = item["powerLe"].Value<float>(),
                                powerkW = item["powerkW"].Value<float>(),
                                engineSize = item["engineSize"].Value<float>(),
                                drivingLicence = item["drivingLicence"].ToString(),
                                places = item["places"].Value<int>(),
                                price = item["price"].Value<int>(),
                                deposit = item["deposit"].Value<int>(),
                                image = item["image"].ToString(),
                                trafficDate = item["trafficDate"].Value<DateTime>(),
                                location = item["location"].ToString(),
                                isInService = item["isInService"].Value<bool>(),
                                problamComment = item["problamComment"].ToString(),
                            };
                            motorList.Add(motor);
                        }
                    }
                }
                return motorList;
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Add Motor to the database
        public async Task AddMotorAsync(Dictionary<string, object> addData, string motorBrand, 
            string motorType, int CurrentAdminId, AdminModel LoggedAdmin, string imagePath)
        {
            try
            {
                var uri = "http://127.0.0.1:8000/api/AddMotor";
                var content = new MultipartFormDataContent();

                // Szöveges mezők hozzáadása
                foreach (var item in addData)
                {
                    if (item.Value != null)
                    {
                        content.Add(new StringContent(item.Value.ToString()), item.Key);
                    }
                }

                // Kép feltöltése
                if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                {
                    var stream = File.OpenRead(imagePath);
                    var fileContent = new StreamContent(stream);

                    // MIME típus automatikus meghatározása
                    var mimeType = GetMimeType(imagePath);
                    fileContent.Headers.ContentType = new MediaTypeHeaderValue(mimeType);

                    content.Add(fileContent, "image", Path.GetFileName(imagePath));
                }

                var response = await _httpClient.PostAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    var log = new LogModel
                    {
                        command = $"Sikeresen HOZZÁADTA a {motorBrand}-{motorType} motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                    {
                        { "LoggedInUser", LoggedAdmin }
                    };
                    await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();

                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a hozzáadás. Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        // MIME típus meghatározása a fájl kiterjesztése alapján
        private string GetMimeType(string filePath)
        {
            var mimeType = "application/octet-stream";
            var extension = Path.GetExtension(filePath).ToLower();

            switch (extension)
            {
                case ".jpg":
                    mimeType = "image/jpg";
                    break;
                case ".jpeg":
                    mimeType = "image/jpeg";
                    break;
                case ".png":
                    mimeType = "image/png";
                    break;
                case ".gif":
                    mimeType = "image/gif";
                    break;
                case ".svg":
                    mimeType = "image/svg";
                    break;
            }

            return mimeType;
        }


        //Update Motor to the database
        public async Task UpdateMotorAsync(int itemId, Dictionary<string, object> updateData, int CurrentAdminId, int motorId, string type, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/UpdatesMotor/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);
                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen FRISSITETTE a {motorId}, {type} motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", LoggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a frissités. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Delete Motor to the database
        public async Task DeleteMotorAsync(int itemId, string motorBrand, string motorType, int CurrentAdminId, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/DeleteMotor/{itemId}";

                var response = await _httpClient.DeleteAsync(uri);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen TÖRÖLTE a {itemId}. Id-jú {motorBrand}-{motorType} a motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", LoggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a törlés. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString()); 
                throw;
            }
        }

        //Sending a motorcycle to a service in the database
        public async Task UpdateServiceMotorAsync(int itemId, Dictionary<string, object> updateData, int CurrentAdminId, string type, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/UpdatesMotor/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);
                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen FRISSITETTE a {itemId}, {type} a motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                    {
                        {"LoggedInUser", LoggedAdmin }
                    };
                    await Shell.Current.GoToAsync(nameof(ShowMotorcyclePage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a frissités. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Sending out of a motorcycle service in the database
        public async Task UpdateOutServiceMotorAsync(int itemId, Dictionary<string, object> updateData, int CurrentAdminId, string type, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/UpdatesMotor/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);
                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen FRISSITETTE a {itemId}, {type} a motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", LoggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(InServicePage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a frissités. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Get all motor data which is in service
        public async Task<List<MotorcyclesModel>> GetAllInServiceMotorDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("http://127.0.0.1:8000/api/allMotors");

                var jsonObject = JObject.Parse(response);
                var InServicesMotorList = new List<MotorcyclesModel>();

                if (jsonObject["motors"] is JArray loansArray)
                {
                    foreach (var item in loansArray)
                    {
                        if (item["isInService"].Value<bool>() == true)
                        {
                            var motor = new MotorcyclesModel
                            {
                                Id = item["id"].Value<int>(),
                                brand = item["brand"].ToString(),
                                type = item["type"].ToString(),
                                licencePlate = item["licencePlate"].ToString(),
                                year = item["year"].Value<int>(),
                                gearbox = item["gearbox"].ToString(),
                                fuel = item["fuel"].ToString(),
                                powerLe = item["powerLe"].Value<float>(),
                                powerkW = item["powerkW"].Value<float>(),
                                engineSize = item["engineSize"].Value<float>(),
                                drivingLicence = item["drivingLicence"].ToString(),
                                places = item["places"].Value<int>(),
                                price = item["price"].Value<int>(),
                                deposit = item["deposit"].Value<int>(),
                                image = item["image"].ToString(),
                                trafficDate = item["trafficDate"].Value<DateTime>(),
                                location = item["location"].ToString(),
                                //isInService = item["isInService"].Value<bool>(),
                                problamComment = item["problamComment"].ToString(),
                                //deleted_at = item["deposit"].Value<DateTime>(),
                            };
                            InServicesMotorList.Add(motor);
                        }
                    }
                }
                return InServicesMotorList;
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

    }
}
