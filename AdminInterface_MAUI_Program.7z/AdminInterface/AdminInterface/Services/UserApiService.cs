﻿using AdminInterface.Models;
using AdminInterface.Pages.UserPages.DrivingLicenceCheckPages;
using AdminInterface.Pages.UserPages.RentalPages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

namespace AdminInterface.Services
{
    public class UserApiService
    {
        private readonly HttpClient _httpClient;
        private AdminService adminService;

        public UserApiService()
        {
            _httpClient = new HttpClient();
            adminService = new AdminService();
        }

        //Get all rental data from the database
        public async Task<List<UserLoanInfoModel>> GetDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("http://127.0.0.1:8000/api/usersData");

                var jsonObject = JObject.Parse(response);
                var loansList = new List<UserLoanInfoModel>();

                if (jsonObject["loans"] is JArray loansArray)
                {
                    foreach (var item in loansArray)
                    {
                        if (item["gaveDown"].ToString() == "0")
                        {
                            var loan = new UserLoanInfoModel
                            {
                                Id = item["id"].Value<int>(),
                                RentalDate = item["rentalDate"].Value<DateTime>(),
                                ReturnDate = item["returnDate"].Value<DateTime>(),
                                orders_id = item["orders_id"].ToString(),
                                motorId = item["motorcycle"]["id"].Value<int>(),
                                brand = item["motorcycle"]["brand"].ToString(),
                                type = item["motorcycle"]["type"].ToString(),
                                licencePlate = item["motorcycle"]["licencePlate"].ToString(),
                                year = item["motorcycle"]["year"].Value<int>(),
                                gearbox = item["motorcycle"]["gearbox"].ToString(),
                                fuel = item["motorcycle"]["fuel"].ToString(),
                                powerLe = item["motorcycle"]["powerLe"].Value<double>(),
                                powerkW = item["motorcycle"]["powerkW"].Value<double>(),
                                engineSize = item["motorcycle"]["engineSize"].Value<double>(),
                                drivingLicence = item["motorcycle"]["drivingLicence"].ToString(),
                                location = item["motorcycle"]["location"].ToString(),
                                image = item["motorcycle"]["image"].ToString(),
                                problamComment = item["motorcycle"]["problamComment"].ToString(),
                                name = item["user"]["name"].ToString(),
                                email = item["user"]["email"].ToString(),
                                phoneNumber = item["user"]["phoneNumber"].ToString(),
                                drivingLicenceNumber = item["user"]["drivingLicenceNumber"].ToString(),
                                drivingLicenceType = item["user"]["drivingLicenceType"].ToString(),
                                frontDrivingLicenceCard = item["user"]["drivingLicenceImage"].ToString(),
                                backDrivingLicenceCard = item["user"]["drivingLicenceImageBack"].ToString(),


                                ToolsList = new List<Tools>()
                            };

                            if (item["device_switches"] is JArray deviceSwitchesArray)
                            {
                                loan.ToolsList = deviceSwitchesArray
                                    .Select(switchItem => switchItem["tool"])
                                    .Where(tool => tool != null) // Üres vagy null eszközök kihagyása
                                    .Select(tool => new Tools
                                    {
                                        toolName = tool["toolName"].ToString(),
                                        size = tool["size"].ToString()
                                    }).ToList();
                            }

                            loansList.Add(loan);
                        }
                    }
                    return loansList;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }


        //It is called on return
        public async Task UpdateRetrieveMotorAsync(int itemId, int motorId, Dictionary<string, object> updateData, int CurrentAdminId, string problams, string brand, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/retrieveData/{itemId}/{motorId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);
                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    var log = new LogModel
                    {
                        command = $"Sikeresen VISSZAVETTE a motort. Problémák: {problams}",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                    {
                        {"LoggedInUser", LoggedAdmin }
                    };
                    await Shell.Current.GoToAsync(nameof(ShowUsersPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a visszavétel. Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }


        //It is called on rental
        public async Task TakenFromMotorAsync(int itemId, Dictionary<string, object> updateData, int CurrentAdminId, string type, string brand, string username, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/receiptMotorData/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"{username}-nak sikeresen ÁTADTA a {brand} {type} motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", LoggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowUsersPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült az átadás. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Get all user data from the database
        public async Task<List<UserModel>> GetAlluserDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("http://127.0.0.1:8000/api/allUsers");

                var jsonObject = JObject.Parse(response);
                var userList = new List<UserModel>();

                if (jsonObject["users"] is JArray loansArray)
                {
                    foreach (var item in loansArray)
                    {
                        if (item["drivingLicenceReal"].Value<bool>() == false)
                        {
                            var users = new UserModel
                            {
                                Id = item["id"].Value<int>(),
                                name = item["name"].ToString(),
                                email = item["email"].ToString(),
                                phoneNumber = item["phoneNumber"].ToString(),
                                drivingLicenceNumber = item["drivingLicenceNumber"].ToString(),
                                drivingLicenceType = item["drivingLicenceType"].ToString(),
                                frontDrivingLicenceCard = item["drivingLicenceImage"].ToString(),
                                backDrivingLicenceCard = item["drivingLicenceImageBack"].ToString(),
                                //drivingLicenceReal = item["drivingLicenceReal"].Value<bool>(),
                            };

                            userList.Add(users);
                        }
                    }
                }
                return userList;
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //It is called on validation
        public async Task UpdateValidationAsync(int itemId, Dictionary<string, object> updateData, string UserName, int CurrentAdminId, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/user/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen JÓVÁHAGYTA a {UserName}-et motort",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", LoggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowAllUserPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a művelet. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Delete rental to the database
        public async Task DeleteRentalAsync(int itemId, string orederId, int CurrentAdminId, AdminModel LoggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/delete-order/{itemId}";

                var response = await _httpClient.DeleteAsync(uri);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen TÖRÖLTE a {itemId} Rendelést",
                        date = formattedDate,
                        admin_id = CurrentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", LoggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowUsersPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a törlés. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

    }
}
