﻿using AdminInterface.Models;
using Newtonsoft.Json;
using System.Text;

namespace AdminInterface.Services
{
    public class AdminService
    {
        private readonly HttpClient _httpClient;

        public AdminService()
        {
            _httpClient = new HttpClient();
        }

        // Add Log to the database
        public async Task AddLog(LogModel log)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/AddLog";

                var content = new StringContent(JsonConvert.SerializeObject(log), Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(uri, content);

                if (!response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();

                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a hozzáadás. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        // Get all logs from the database
        public async Task AddAdminIntoDatabaseAsync(Dictionary<string, object> addData, int jobStatus)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/admins";

                var content = new StringContent(JsonConvert.SerializeObject(addData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(uri, content);

                string jobStatusText = "";

                switch (jobStatus)
                {
                    case 0:
                        jobStatusText = "SzuperAdmin";
                        break;
                    case 1:
                        jobStatusText = "Szerelő";
                        break;
                    case 2:
                        jobStatusText = "Recepciós";
                        break;
                }

                if (!response.IsSuccessStatusCode)
                {
                    string responseContent = await response.Content.ReadAsStringAsync();

                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a hozzáadás. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

    }
}
