﻿using AdminInterface.Models;
using AdminInterface.Pages.SuperAdminPages;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

namespace AdminInterface.Services
{
    public class SuperAdminService
    {
        private readonly HttpClient _httpClient;
        private AdminService adminService;

        public SuperAdminService()
        {
            _httpClient = new HttpClient();
            adminService = new AdminService();
        }

        // Get all admins from the database
        public async Task<List<AdminModel>> GetLogsDataAsync()
        {
            try
            {
                var response = await _httpClient.GetStringAsync("http://127.0.0.1:8000/api/logs");

                var jsonObject = JObject.Parse(response);
                var adminLogList = new List<AdminModel>();

                if (jsonObject["0"] is JArray adminLogArray)
                {
                    foreach (var item in adminLogArray)
                    {
                        var admin = new AdminModel
                        {
                            Id = item["id"].Value<int>(),
                            name = item["name"].ToString(),
                            email = item["email"].ToString(),
                            password = item["password"].ToString(),
                            jobStatus = item["jobStatus"].Value<byte>(),
                            deleted_at = item["deleted_at"] != null ? item["deleted_at"].Value<DateTime?>() : null,
                            Logs = new List<LogModel>()
                        };

                        if (item["logs"] is JArray logsArray)
                        {
                            admin.Logs = logsArray.Where(logItem => logItem != null).Select(logItem => new LogModel
                            {
                                Id = logItem["id"].Value<int>(),
                                command = logItem["command"].ToString(),
                                date = logItem["date"].ToString(),
                            }).ToList();
                        }

                        adminLogList.Add(admin);

                    }
                    return adminLogList;
                }
                else
                {
                    return null;
                }
            }
            catch (HttpRequestException httpEx)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, httpEx.ToString());
            }
            return new List<AdminModel>();
        }

        //Add Admin to the database
        public async Task AddAdminAsync(Dictionary<string, object> addData, int currentAdminId, 
            AdminModel loggedAdmin, string name, int jobStatus)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/admins";

                var content = new StringContent(JsonConvert.SerializeObject(addData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(uri, content);

                string jobStatusText = "";

                switch (jobStatus)
                {
                    case 0:
                        jobStatusText = "SzuperAdmin";
                        break;
                    case 1:
                        jobStatusText = "Szerelő";
                        break;
                    case 2:
                        jobStatusText = "Recepciós";
                        break;
                }

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    var log = new LogModel
                    {
                        command = $"Sikeresen HOZZÁADTA {name} {jobStatusText} admint.",
                        date = formattedDate,
                        admin_id = currentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                    {
                        {"LoggedInUser", loggedAdmin }
                    };
                    await Shell.Current.GoToAsync(nameof(ShowAdminsPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a hozzáadás. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

        //Update Admin to the database
        public async Task UpdateAdminAsync(int itemId, Dictionary<string, object> updateData,
            int currentAdminId, string adminName, AdminModel loggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/admins/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    var log = new LogModel
                    {
                        command = $"Sikeresen MÓDOSÍTOTTA az {adminName} admint.",
                        date = formattedDate,
                        admin_id = currentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", loggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowAdminsPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a frissités. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }


        //Deactivate Admin from the database
        public async Task DeleteAdminAsync(int itemId, int currentAdminId, string currentAdminName, AdminModel loggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/DeactiveAdmin/{itemId}";

                var response = await _httpClient.DeleteAsync(uri);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    var log = new LogModel
                    {
                        command = $"Sikeresen deaktiválta  {currentAdminName}-ot(-ét) az {currentAdminId} számú Id-val ",
                        date = formattedDate,
                        admin_id = currentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", loggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowAdminsPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a törlés. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }



        //Admin reactivation in the database
        public async Task ReStoreAdminAsync(int itemId, Dictionary<string, object> updateData, int currentAdminId, string currentAdminName, AdminModel loggedAdmin)
        {
            try
            {
                var uri = $"http://127.0.0.1:8000/api/RestoreAdmin/{itemId}";

                var content = new StringContent(JsonConvert.SerializeObject(updateData), Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(uri, content);

                if (response.IsSuccessStatusCode)
                {
                    string formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    var log = new LogModel
                    {
                        command = $"Sikeresen frissitette az {currentAdminId} Id ",
                        date = formattedDate,
                        admin_id = currentAdminId,
                    };
                    await adminService.AddLog(log);

                    var parameters = new Dictionary<string, object>
                {
                    {"LoggedInUser", loggedAdmin }
                };
                    await Shell.Current.GoToAsync(nameof(ShowAdminsPage), parameters);
                }
                else
                {
                    string responseContent = await response.Content.ReadAsStringAsync();
                    await Shell.Current.DisplayAlert("Hiba", $"Nem sikerült a visszaállítás. \n Részletek: {responseContent}", "OK");
                }
            }
            catch (Exception ex)
            {
                string filePath = Path.Combine(FileSystem.AppDataDirectory, "error.txt");
                File.WriteAllText(filePath, ex.ToString());
                throw;
            }
        }

    }
}
