namespace AdminInterface.Pages.MotorPages;

public partial class DetailShowMotorcyclePage : ContentPage
{
	public DetailShowMotorcyclePage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Motor r�szletes adatai";
    }

}