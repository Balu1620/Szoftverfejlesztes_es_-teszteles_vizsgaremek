namespace AdminInterface.Pages.MotorPages;

public partial class EditMotorcyclePage : ContentPage
{
	public EditMotorcyclePage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Motor kezel�se";
    }

}