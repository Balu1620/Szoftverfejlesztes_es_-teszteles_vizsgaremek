namespace AdminInterface.Pages.MotorPages;

public partial class NoteProblamMotorcyclePage : ContentPage
{
	public NoteProblamMotorcyclePage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Probl�mabejegyz�s";
    }

}