namespace AdminInterface.Pages.MotorPages;

public partial class ShowMotorcyclePage : ContentPage
{
	public ShowMotorcyclePage()
	{
		InitializeComponent();
	}

    private void DatasList_SizeChanged(object sender, EventArgs e)
    {
        double dpWidth = this.Width / DeviceDisplay.MainDisplayInfo.Density;

        int columns = 0;

        columns = dpWidth < 800 ? 2 : 3;

        if (dpWidth > 1501)
        {
            columns = 5;
        }
        else if (dpWidth > 1001 && dpWidth < 1500)
        {
            columns = 4;
        }
        else if (dpWidth > 811 && dpWidth < 1000)
        {
            columns = 3;
        }
        else if (dpWidth > 601 && dpWidth < 810)
        {
            columns = 2;
        }
        else if (dpWidth < 600)
        {
            columns = 1;
        }



        if (DatasList.ItemsLayout is GridItemsLayout gridItemsLayout)
        {
            gridItemsLayout.Span = columns;
        }
        else
        {
            DatasList.ItemsLayout = new GridItemsLayout(columns, ItemsLayoutOrientation.Vertical);
        }
               

    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Motorok";
    }

}