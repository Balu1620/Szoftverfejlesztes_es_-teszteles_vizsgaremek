namespace AdminInterface.Pages.MotorPages;

public partial class InServicePage : ContentPage
{
	public InServicePage()
	{
		InitializeComponent();
	}

    private void DatasList_SizeChanged(object sender, EventArgs e)
    {
        double dpWidth = this.Width / DeviceDisplay.MainDisplayInfo.Density;

        int columns = 0;

        columns = dpWidth < 800 ? 2 : 3;

        if (dpWidth > 1501)
        {
            columns = 5;
        }
        else if (dpWidth > 1401 && dpWidth < 1640)
        {
            columns = 4;
        }
        else if (dpWidth > 1000 && dpWidth < 1400)
        {
            columns = 3;
        }
        else if (dpWidth > 651 && dpWidth < 950)
        {
            columns = 2;
        }
        else if (dpWidth < 650)
        {
            columns = 1;
        }



        if (DatasList.ItemsLayout is GridItemsLayout gridItemsLayout)
        {
            gridItemsLayout.Span = columns;
        }
        else
        {
            DatasList.ItemsLayout = new GridItemsLayout(columns, ItemsLayoutOrientation.Vertical);
        }

    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Szerviz";
    }

}