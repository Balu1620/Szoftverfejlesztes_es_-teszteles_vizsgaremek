using System.Globalization;

namespace AdminInterface.Pages.MotorPages;

public partial class AddMotorcyclePage : ContentPage
{
	public AddMotorcyclePage()
	{
		InitializeComponent();
		calendar.MinimumDate = DateTime.Now;
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "�j motor felv�tele";
    }




}