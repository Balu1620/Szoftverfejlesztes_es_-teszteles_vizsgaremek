namespace AdminInterface.Pages.UserPages.RentalPages;

public partial class ProblemReporting : ContentPage
{
    private List<string> problemak = new List<string>();
    public ProblemReporting()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Motor ellen�rz�s";
    }
    private void OnCheckboxCheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        if (egy_null.IsChecked == true && egy_egy.IsChecked == true && egy_ketto.IsChecked == true &&
            ketto_null.IsChecked == true && ketto_egy.IsChecked == true && ketto_ketto.IsChecked == true && 
            harom_null.IsChecked == true && harom_egy.IsChecked == true && harom_ketto.IsChecked == true &&
            negy_null.IsChecked == true && negy_egy.IsChecked == true && negy_ketto.IsChecked == true &&
            ot_null.IsChecked == true && ot_egy.IsChecked == true && ot_ketto.IsChecked == true &&
            hat_null.IsChecked == true ){
            
            FinishButton.IsEnabled = true;
        }
    }

    private void WriteCheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        if (sender is CheckBox checkbox)
        {
            string problemText = GetLabelTextForCheckbox(checkbox);

            if (e.Value)
            {
                if (!problemak.Contains(problemText))
                {
                    problemak.Add(problemText);
                }
            }
            else
            {
                problemak.Remove(problemText);
            }

            Problema.Text = string.Join("", problemak);
        }
    }
    private string GetLabelTextForCheckbox(CheckBox checkbox)
    {
        switch (checkbox.StyleId)
        {
            case "egy_null_felirasa": return "- A motor nem tiszta vagy s�r�lt \n";
            case "egy_egy_felirasa": return "- Karcol�sok, t�r�sek vagy horpad�sok vannak \n";
            case "egy_ketto_felirasa": return "- Hi�nyz� alkatr�szek (t�kr�k, indexek, l�mp�k) \n";
            case "ketto_null_felirasa": return "- A gumik �llapota nem megfelel� \n";
            case "ketto_egy_felirasa": return "- A gumik l�gnyom�sa nem megfelel� \n";
            case "ketto_ketto_felirasa": return "- A felnik s�r�ltek \n";
            case "harom_null_felirasa": return "- A f�kek nem m�k�dnek megfelel�en \n";
            case "harom_egy_felirasa": return "- A f�kbet�tek vagy t�rcs�k kopottak \n";
            case "harom_ketto_felirasa": return "- A teleszk�pok sziv�rognak \n";
            case "negy_null_felirasa": return "- Egy vagy t�bb l�mpa/index nem m�k�dik \n";
            case "negy_egy_felirasa": return "- A k�rt nem m�k�dik \n";
            case "negy_ketto_felirasa": return "- A m�szerfalon hiba�zenet van \n";
            case "ot_null_felirasa": return "- Az olajszint nem megfelel� \n";
            case "ot_egy_felirasa": return "- Sziv�rg�s van (olaj, �zemanyag, h�t�folyad�k) \n";
            case "ot_ketto_felirasa": return "- A motor nem indul k�nnyen vagy rendellenesen m�k�dik \n";
            case "hat_null_felirasa": return "- A kulcsokat nem hozt�k vissza \n";
            default: return "- Ismeretlen probl�ma \n";
        }
    }
}
