namespace AdminInterface.Pages.UserPages.RentalPages.PicturesInLargePages;

public partial class FrontDrivingLicenceImage : ContentPage
{
	public FrontDrivingLicenceImage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "  ";
    }

}