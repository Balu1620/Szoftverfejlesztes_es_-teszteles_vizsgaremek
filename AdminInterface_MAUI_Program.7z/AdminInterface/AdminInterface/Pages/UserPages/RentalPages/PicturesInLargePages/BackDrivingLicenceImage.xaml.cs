namespace AdminInterface.Pages.UserPages.RentalPages.PicturesInLargePages;

public partial class BackDrivingLicenceImage : ContentPage
{
    public BackDrivingLicenceImage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "  ";
    }
}