namespace AdminInterface.Pages.UserPages.RentalPages;

public partial class DetailShowPage : ContentPage
{
	public DetailShowPage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "B�rl�s r�szletei";
    }
}