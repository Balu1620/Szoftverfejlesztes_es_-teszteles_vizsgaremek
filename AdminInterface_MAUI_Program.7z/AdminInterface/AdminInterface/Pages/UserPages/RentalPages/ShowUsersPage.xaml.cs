namespace AdminInterface.Pages.UserPages.RentalPages;

public partial class ShowUsersPage : ContentPage
{
    public ShowUsersPage()
    {
        InitializeComponent();
    }
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "K�lcs�nz�sek";
    }

    private void DatasList_SizeChanged(object sender, EventArgs e)
    {
        double dpWidth = this.Width / DeviceDisplay.MainDisplayInfo.Density;

        int columns = 0;

        columns = dpWidth < 1000 ? 2 : 3;

        if (dpWidth > 1901)
        {
            columns = 5;
        }
        else if (dpWidth > 1201 && dpWidth < 1700)
        {
            columns = 4;
        }
        else if (dpWidth > 1011 && dpWidth < 1200)
        {
            columns = 3;
        }
        else if (dpWidth > 601 && dpWidth < 1010)
        {
            columns = 2;
        }
        else if (dpWidth < 600)
        {
            columns = 1;
        }



        if (DatasList.ItemsLayout is GridItemsLayout gridItemsLayout)
        {
            gridItemsLayout.Span = columns;
        }
        else
        {
            DatasList.ItemsLayout = new GridItemsLayout(columns, ItemsLayoutOrientation.Vertical);
        }

    }
}