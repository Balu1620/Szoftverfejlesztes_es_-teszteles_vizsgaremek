namespace AdminInterface.Pages.UserPages.DrivingLicenceCheckPages;

public partial class DetailShowUserCheckPage : ContentPage
{
	public DetailShowUserCheckPage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Felhaszn�l�i adatok ellen�rz�se";
    }

}