namespace AdminInterface.Pages.UserPages.DrivingLicenceCheckPages;

public partial class ShowAllUserPage : ContentPage
{
	public ShowAllUserPage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Jogos�tv�ny ellen�rz�s";
    }

}