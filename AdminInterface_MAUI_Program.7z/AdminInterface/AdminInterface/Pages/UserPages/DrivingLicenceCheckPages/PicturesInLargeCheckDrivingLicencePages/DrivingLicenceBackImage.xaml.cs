namespace AdminInterface.Pages.UserPages.DrivingLicenceCheckPages.PicturesInLargeCheckDrivingLicencePages;

public partial class DrivingLicenceBackImage : ContentPage
{
	public DrivingLicenceBackImage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "  ";
    }

}