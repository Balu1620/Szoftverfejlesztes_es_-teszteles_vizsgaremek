namespace AdminInterface.Pages.UserPages.DrivingLicenceCheckPages.PicturesInLargeCheckDrivingLicencePages;

public partial class DrivingLicenceFrontImage : ContentPage
{
	public DrivingLicenceFrontImage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "  ";
    }

}