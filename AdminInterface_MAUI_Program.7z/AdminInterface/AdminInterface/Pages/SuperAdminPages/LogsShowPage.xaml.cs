namespace AdminInterface.Pages.SuperAdminPages;

public partial class LogsShowPage : ContentPage
{
	public LogsShowPage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "M�veleti napl�";
    }

}