namespace AdminInterface.Pages.SuperAdminPages;

public partial class ShowAdminsPage : ContentPage
{
	public ShowAdminsPage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "F�oldal";
    }

}