namespace AdminInterface.Pages.SuperAdminPages;

public partial class DeleteAdminPage : ContentPage
{
	public DeleteAdminPage()
	{
		InitializeComponent();


	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Deaktiv�lt adminok";
    }

}