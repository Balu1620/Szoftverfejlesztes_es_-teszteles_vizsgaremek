namespace AdminInterface.Pages.SuperAdminPages;

public partial class EditAdminPage : ContentPage
{
	public EditAdminPage()
	{
		InitializeComponent();
	}

    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Felhaszn�l� kezel�s";
    }

}