namespace AdminInterface.Pages.SuperAdminPages;

public partial class AddAdminPage : ContentPage
{
	public AddAdminPage()
	{
		InitializeComponent();
	}
    protected override void OnAppearing()
    {
        base.OnAppearing();
        this.Title = "Admin hozz�ad�sa";
    }

}