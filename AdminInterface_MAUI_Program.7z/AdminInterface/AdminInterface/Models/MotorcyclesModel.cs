﻿using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminInterface.Models
{
    public class MotorcyclesModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        [Required]
        public string brand { get; set; } = string.Empty;
        [Required]
        public string type { get; set; } = string.Empty;
        [Required]
        public string licencePlate { get; set; } = string.Empty;
        [Required]
        public int year { get; set; } = 0;
        [Required]
        public string gearbox { get; set; } = string.Empty;
        [Required]
        public string fuel { get; set; } = string.Empty;
        [Required]
        public float powerLe { get; set; } = 0;
        [Required]
        public float powerkW { get; set; } = 0;
        [Required]
        public float engineSize { get; set; } = 0;
        [Required]
        public string drivingLicence { get; set; } = string.Empty;
        [Required]
        public int places { get; set; } = 0;
        [Required]
        public int price { get; set; } = 0;
        [Required]
        public int deposit { get; set; } = 0;
        [Required]
        public string image { get; set; } = string.Empty;
        [Required]
        public bool HasProblem => (!string.IsNullOrWhiteSpace(problamComment) || trafficDate < DateTime.Now);
        [Required]
        public DateTime trafficDate { get; set; } = DateTime.Now;
        [Required]
        public string location { get; set; } = string.Empty;
        [Required]
        public bool isInService { get; set; } = false;
        [Required]
        public string problamComment { get; set; } = string.Empty;
        public DateTime? deleted_at { get; set; } = null;
    }
}
