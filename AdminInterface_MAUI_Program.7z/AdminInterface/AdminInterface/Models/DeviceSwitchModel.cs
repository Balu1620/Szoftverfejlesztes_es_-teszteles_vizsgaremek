﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminInterface.Models
{
    public class DeviceSwitchModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        public int ToolId { get; set; }
        public ToolModel Tool { get; set; }

        public int LoanId { get; set; }
        public LoanModel Loan { get; set; }
        
    }
}
