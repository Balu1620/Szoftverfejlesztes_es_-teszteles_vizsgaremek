﻿namespace AdminInterface.Models
{
    public class UserLoanInfoModel
    {
        public int Id { get; set; }
        public DateTime RentalDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public bool gaveDown { get; set; }
        public bool jobStatus  { get; set; }
        public string orders_id { get; set; }

        // Motorcycle
        public int motorId { get; set; }
        public string brand { get; set; }
        public string type { get; set; }
        public string licencePlate { get; set; }
        public int year { get; set; }
        public string gearbox { get; set; }
        public string fuel { get; set; }
        public double powerLe { get; set; }
        public double powerkW { get; set; }
        public double engineSize { get; set; }
        public string drivingLicence { get; set; }
        public string problamComment { get; set; }
        public string image { get; set; }
        public string location { get; set; }

        public bool IsDelDisable => !string.IsNullOrEmpty(location);

        // User
        public string name { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
        public string drivingLicenceNumber { get; set; }
        public string drivingLicenceType { get; set; }
        public string frontDrivingLicenceCard { get; set; }
        public string backDrivingLicenceCard { get; set; }
        public bool drivingLicenceReal { get; set; }
        //tools
        public List<Tools> ToolsList { get; set; }

    }

    public class Tools
    {
        public string toolName { get; set; }
        public string size { get; set; }
    }
}
