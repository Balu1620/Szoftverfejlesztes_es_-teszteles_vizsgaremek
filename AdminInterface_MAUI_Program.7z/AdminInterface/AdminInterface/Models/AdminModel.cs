﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminInterface.Models
{
    public class AdminModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        [Required]
        public string name { get; set; } = string.Empty;
        [Required]
        public string email { get; set; } = string.Empty;
        [Required]
        public string password { get; set; } = string.Empty;
        [Required]
        public byte jobStatus { get; set; } = 0; // 0: Szuperadmin, 1: Szerelő, 2: Recepciós

        public string JobStatusText => jobStatus switch
        {
            0 => "Szuperadmin",
            1 => "Szerelő",
            2 => "Recepciós",
            _ => "Ismeretlen",
        };
        // public DateTime? deleted_at { get; set; }

        public DateTime? deleted_at { get; set; } = null;
        [Required]
        public List<LogModel> Logs { get; set; } = new List<LogModel>();
    }
}
