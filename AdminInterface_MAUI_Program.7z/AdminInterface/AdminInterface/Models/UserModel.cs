﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdminInterface.Models
{
    public class UserModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string drivingLicenceNumber { get; set; }
        public string drivingLicenceType { get; set; }
        public string phoneNumber { get; set; }
        public string frontDrivingLicenceCard { get; set; }
        public string backDrivingLicenceCard { get; set; }
        public bool drivingLicenceReal {  get; set; }
        //public List<LoanModel> Loans { get; set; }
    }
}
