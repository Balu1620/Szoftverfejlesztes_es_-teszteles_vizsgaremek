﻿using AdminInterface.ViewModels;

namespace AdminInterface
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            emailInput.Text = "";
            passwordInput.Text = "";
        }

    }

}
