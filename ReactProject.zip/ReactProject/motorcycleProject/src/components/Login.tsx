import React, { useState } from "react";
import { useLoanContext } from "../context/loanContext";
import "../styles/Login.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { handleLogin, loading, error } = useLoanContext();

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    await handleLogin(email, password);
  };

  return (
    <div id="login-page-container">
      <div id="login-box">
        <h2>Bejelentkezés</h2>
        {error && <div className="error-message">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">Email</label>
            <input
              type="text"
              id="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Írd be az email címed"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Jelszó</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Írd be a jelszavad"
            />
          </div>
          
          <button type="submit" className="submit-button" disabled={loading}>
            {loading ? "Bejelentkezés..." : "Bejelentkezés"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Login;
