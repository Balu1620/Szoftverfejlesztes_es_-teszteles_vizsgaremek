import { Link, useNavigate } from "react-router-dom";
import { useLoanContext } from "../context/loanContext";

const Navbar = () => {
  const {handleLogout } = useLoanContext();
  const navigate = useNavigate();

  // Akkor jelenjen meg a kijelentkezés gomb, ha be van jelentkezve a felhasználó
  const isLoggedIn = !!localStorage.getItem("authToken");

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link to="/Dashboard" className="navbar-brand fw-bold">
          Profil
        </Link>
        <Link to="/MainPage" className="navbar-brand fw-bold">
          Főoldal
        </Link>
        <Link to="/Motors" className="navbar-brand fw-bold">
        Foglalj most!
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            {isLoggedIn ? (
              <li className="nav-item">
                <button
                  className="nav-link btn btn-danger text-white fw-semibold px-4"
                  onClick={handleLogout}
                  style={{ border: "none", background: "none" }}
                >
                  Kijelentkezés
                </button>
              </li>
            ) : (
              <li className="nav-item">
                <Link to="/login" className="nav-link btn btn-warning text-white fw-semibold px-4">
                  Bejelentkezés
                </Link>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
