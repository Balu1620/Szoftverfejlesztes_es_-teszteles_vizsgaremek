import "../styles/HomePage.css";

const HomePage = () => {
  return (
    <div className="homepage">
      {/* Hero Section */}
      <header className="hero">
        <h1>Bérelj csak nálunk!</h1>
        <p>Fedezd fel a legjobb motorokat a legjobb árakon!</p>
      </header>

      {/* Services Section */}
      <section className="services">
        <h2>Miért válassz minket?</h2>
        <div className="service-cards">
          <div className="service-card">
            <h3>Széles választék</h3>
            <p>Válassz a sportmotorok, robogók és túramotorok közül!</p>
          </div>
          <div className="service-card">
            <h3>Kedvező árak</h3>
            <p>Költséghatékony megoldások minden motoros számára.</p>
          </div>
          <div className="service-card">
            <h3>Professzionális támogatás</h3>
            <p>Segítőkész ügyfélszolgálat és megbízható szerviz.</p>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="gallery">
        <h2>Népszerű motorok</h2>
        <div className="gallery-images">
          <img src={`http://localhost:8000/storage/img/400X.jpg`} alt="Sportmotor" />
          <img src={`http://localhost:8000/storage/img/Address.jpg`} alt="Robogó" />
          <img src={`http://localhost:8000/storage/img/aerox155.jpg`} alt="Túramotor" />
        </div>
      </section>
    </div>
  );
};

export default HomePage;
