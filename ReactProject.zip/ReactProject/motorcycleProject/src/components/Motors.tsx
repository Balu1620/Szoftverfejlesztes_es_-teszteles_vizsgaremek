import { useState, useEffect } from "react";
import { useLoanContext } from "../context/loanContext"; 
import "../styles/MotorcycleDetails.css"; 

const MotorcycleList = () => {
  const {
    motorcycles,
    loading,
    error,
    fetchMotorcycles,
  } = useLoanContext();

  const [filterState] = useState({
    brand: "",
    year: "",
    gearbox: "",
    location: "",
    dateStart: "",
    dateEnd: "",
  });

  useEffect(() => {
    fetchMotorcycles(filterState);
  }, [filterState, fetchMotorcycles]);

  // Ha éppen töltődik az adat
  if (loading) {
    return <div className="loading"></div>;
  }

  // Ha hiba történt az adatok betöltése során
  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h1>Elérhető motorok</h1>

      {/* Motorok listája */}
      <div className="motorcycle-list">
        {motorcycles.length > 0 ? (
          motorcycles.map((motorcycle) => (
            <div key={motorcycle.id} className="motorcycle-card">
              <img src={`http://localhost:8000/storage/img/${motorcycle.image}`} alt={motorcycle.type} />
              <div className="details">
                <h3>{motorcycle.brand} - {motorcycle.type}</h3>
                <p>{motorcycle.year} | {motorcycle.gearbox} | {motorcycle.location}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="no-motorcycles">Nincsenek elérhető motorok</p>
        )}
      </div>
    </div>
  );
};

export default MotorcycleList;
