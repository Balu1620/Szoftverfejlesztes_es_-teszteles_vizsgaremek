import { useEffect } from "react";
import { useLoanContext } from "../context/loanContext";
import "../styles/Dashboard.css";

const Dashboard = () => {
  const { userData, loans, loading, error, handleDeleteOrder, fetchUserData } =
    useLoanContext();

  //Így csak egyszer fut le a komponens betöltésekor
  useEffect(() => {
    fetchUserData();
  }, []);

  // Feltételes renderelés a betöltési és hiba állapotokhoz
  if (loading) return <div className="loading">Adatok betöltése...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="dashboard-container">
      <h1 className="dashboard-title">Felhasználói Profil</h1>
      {userData && (
        <div className="user-profile-section">
          <h2>Személyes Adatok</h2>
          <div className="user-info">
            <p>
              <strong>Név:</strong> {userData.name}
            </p>
            <p>
              <strong>Email:</strong> {userData.email}
            </p>
            <p>
              <strong>Telefonszám:</strong> {userData.phoneNumber}
            </p>
            <p>
              <strong>Vezetői engedély száma:</strong>{" "}
              {userData.drivingLicenceNumber}
            </p>
            <p>
              <strong>Vezetői engedély típusa:</strong>{" "}
              {userData.drivingLicenceType}
            </p>

            <div className="driving-licence-container">
              {userData.drivingLicenceImage && (
                <div className="driving-licence-image">
                  <h3>Jogosítvány Előlap</h3>
                  <img
                    src={userData.drivingLicenceImage}
                    alt="Jogosítvány Előlap"
                    className="driving-licence-img"
                  />
                </div>
              )}
              {userData.drivingLicenceImageBack && (
                <div className="driving-licence-image">
                  <h3>Jogosítvány Hátlap</h3>
                  <img
                    src={userData.drivingLicenceImageBack}
                    alt="Jogosítvány Hátlap"
                    className="driving-licence-img"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {loans && loans.length > 0 ? (
        <div className="loans-section">
          <h2>Aktuális Kölcsönzések</h2>
          {loans.map((loan) => {
            const rentalDate = new Date(loan.rentalDate); 
            const currentDate = new Date(); 
            const oneDayInMs = 24 * 60 * 60 * 1000;            
            const isDeletable = rentalDate.getTime() - currentDate.getTime() > oneDayInMs;
            

            return (
              <div key={loan.id} className="loan-card">
                <div className="loan-details">
                  <h3>Kölcsönzési Adatok</h3>
                  <p>
                    <strong>Rendelési azonosító:</strong> {loan.orders_id}
                  </p>
                  <p>
                    <strong>Kölcsönzés kezdete:</strong> {loan.rentalDate}
                  </p>
                  <p>
                    <strong>Visszahozás dátuma:</strong> {loan.returnDate}
                  </p>

                  {loan.motorcycle && loan.motorcycle.image ? (
                    <div className="motor-image-container">
                      <h3>Motor Kép</h3>
                      <img
                        src={`http://localhost:8000/storage/img/${loan.motorcycle.image}`}
                        alt="Motor"
                        className="motor-image-img"
                      />
                    </div>
                  ) : (
                    <div className="motor-image-container">
                      <h3>Motor Kép</h3>
                      <p>Nem található motor kép.</p>
                    </div>
                  )}
                </div>
                {isDeletable && (
                  <button
                    className="delete-button"
                    onClick={() => {
                      const id = Number(loan.id);
                      if (isNaN(id)) {
                        console.error("Érvénytelen ID:", loan.id);
                        return;
                      }
                      handleDeleteOrder(id);
                    }}
                  >
                    Törlés
                  </button>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="no-loans-message">
          <p>Nincs aktuális kölcsönzésed.</p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
