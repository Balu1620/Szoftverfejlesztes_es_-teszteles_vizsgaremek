import React, {
  createContext,
  useState,
  useEffect,
  ReactNode,
  useContext,
  useCallback,
} from "react";
import { useNavigate } from "react-router-dom";

interface IUser {
  id: number;
  name: string;
  email: string;
  phoneNumber: string;
  drivingLicenceNumber: string;
  drivingLicenceType: string;
  drivingLicenceImage?: string;
  drivingLicenceImageBack?: string;
}

interface IMotorcycle {
  id: number;
  image?: string;
  brand: string;
  type: string;
  year: number;
  gearbox: string;
  fuel: string;
  location: string;
  isInService: number;
}

interface IMotorcycleFilter {
  brands: string[];
  locations: string[];
  years: number[];
  gearboxes: string[];
}

interface ILoan {
  id: number;
  orders_id: number;
  rentalDate: string;
  returnDate: string;
  gaveDown: number;
  problemDescription?: string;
  motorcycle?: IMotorcycle;
}

interface ITool {
  id: number;
  name: string;
}

interface ILoanContext {
  // States
  userData: IUser | null;
  loans: ILoan[];
  tools: ITool[];
  motorcycles: IMotorcycle[];
  filters: IMotorcycleFilter;
  loading: boolean;
  error: string;
  loginError: string;

  handleLogin: (email: string, password: string) => Promise<void>;
  handleLogout: () => void;

  fetchUserData: () => Promise<void>;
  fetchMotorcycles: (filters: any) => Promise<void>;
  handleDeleteOrder: (id: number) => Promise<void>;
  addToolToOrder: (ordersId: number, toolId: number) => Promise<void>;
  deleteTool: (toolId: number) => Promise<void>;
}

const LoanContext = createContext<ILoanContext | undefined>(undefined);

export const LoanProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userData, setUserData] = useState<IUser | null>(null);
  const [loans, setLoans] = useState<ILoan[]>([]);
  const [tools, setTools] = useState<ITool[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [loginError, setLoginError] = useState<string>("");
  const navigate = useNavigate();
  const [motorcycles, setMotorcycles] = useState<IMotorcycle[]>([]);
  const [filters, setFilters] = useState<IMotorcycleFilter>({
    brands: [],
    locations: [],
    years: [],
    gearboxes: [],
  });

  //Fetch motorcycles with filters
  const fetchMotorcycles = useCallback(
    async (filters: any) => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        setLoading(true);
        const url = new URL("http://localhost:8000/api/motorcycles");

        if (filters.brand) url.searchParams.append("brand", filters.brand);
        if (filters.year) url.searchParams.append("year", filters.year);
        if (filters.gearbox) url.searchParams.append("gearbox", filters.gearbox);
        if (filters.fuel) url.searchParams.append("fuel", filters.fuel);
        if (filters.location) url.searchParams.append("location", filters.location);
        if (filters.dateStart) url.searchParams.append("dateStart", filters.dateStart);
        if (filters.dateEnd) url.searchParams.append("dateEnd", filters.dateEnd);

        const response = await fetch(url.toString(), {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        const data = await response.json();

        if (response.ok) {
          setMotorcycles(data.motorcycles || []);
          setFilters(data.filters);
          setError("");
        } else {
          setError(data.msg || "Sikertelen lekérés");
        }
      } catch (error) {
        setError("Hiba a lekérés során");
        console.error("Fetch error:", error);
      } finally {
        setLoading(false);
      }
    },
    [navigate]
  );

  // Fetch user data
  const fetchUserData = useCallback(async () => {
    const token = localStorage.getItem("authToken");
    const userId = localStorage.getItem("userId");
    if (!token || !userId) {
      navigate("/login");
      return;
    }

    try {
      setLoading(true);
      const response = await fetch(
        `http://localhost:8000/api/userProfile/${userId}`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      const data = await response.json();

      if (response.ok) {
        setUserData(data.user || null);
        setLoans(data.loans || []);
        setTools(data.availableTools || []);
        setError("");
      } else {
        setError(data.msg || "Hibás lekérés");
      }
    } catch (error) {
      setError("Hibás lekérés");
      console.error("Fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  // Handle login
  const handleLogin = useCallback(
    async (email: string, password: string) => {
      try {
        setLoading(true);
        setLoginError("");

        const response = await fetch("http://127.0.0.1:8000/api/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email, password }),
        });

        const data = await response.json();

        if (response.ok) {
          localStorage.setItem("authToken", data.token);
          localStorage.setItem("userId", data.userId);
          await fetchUserData();
          navigate("/dashboard");
        } else {
          setLoginError(data.message || "Bejelentkezés sikeretelen.");
        }
      } catch (error) {
        setLoginError("Hiba a bejelentkezés során");
        console.error("Login error:", error);
      } finally {
        setLoading(false);
      }
    },
    [navigate, fetchUserData]
  );

  // Handle logout
  const handleLogout = useCallback(() => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userId");
    setUserData(null);
    setLoans([]);
    setTools([]);
    navigate("/login");
  }, [navigate]);

  // Handle delete order
  const handleDeleteOrder = useCallback(
    async (id: number) => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        setLoading(true);
        const response = await fetch(
          `http://localhost:8000/api/delete-order/${id}`,
          {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        const data = await response.json();

        if (response.ok && data.msg === "Order deleted successfully") {
          setLoans((prevLoans) => prevLoans.filter((loan) => loan.id !== id));
          alert("Order successfully deleted.");
        } else {
          alert(data.msg || "Failed to delete order.");
        }
      } catch (error) {
        alert("Error deleting order.");
        console.error("Delete error:", error);
      } finally {
        setLoading(false);
      }
    },
    [navigate]
  );

  // Handle adding tool to order
  const addToolToOrder = useCallback(
    async (ordersId: number, toolId: number) => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        setLoading(true);
        const response = await fetch(
          `http://localhost:8000/api/${ordersId}/add-tool/`,
          {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ tool_id: toolId }),
          }
        );

        if (response.ok) {
          const updatedRent = await response.json();
          setLoans((prev) =>
            prev.map((loan) =>
              loan.orders_id === ordersId
                ? { ...loan, deviceSwitches: updatedRent.deviceSwitches }
                : loan
            )
          );
        }
      } catch (error) {
        console.error("Error adding tool:", error);
      } finally {
        setLoading(false);
      }
    },
    [navigate]
  );

  // Handle deleting tool
  const deleteTool = useCallback(
    async (toolId: number) => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        setLoading(true);
        const response = await fetch(
          `http://localhost:8000/api/tools/${toolId}`,
          {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        if (response.ok) {
          setTools((prev) => prev.filter((tool) => tool.id !== toolId));
        }
      } catch (error) {
        console.error("Error deleting tool:", error);
      } finally {
        setLoading(false);
      }
    },
    [navigate]
  );

  // Check if token exists when page loads
  useEffect(() => {
    const token = localStorage.getItem("authToken");
    const userId = localStorage.getItem("userId");

    if (token && userId) {
      fetchUserData();
    }
  }, [fetchUserData]);

  return (
    <LoanContext.Provider
      value={{
        userData,
        loans,
        tools,
        motorcycles,
        filters,
        loading,
        error,
        loginError,
        handleLogin,
        handleLogout,
        fetchUserData,
        fetchMotorcycles,
        handleDeleteOrder,
        addToolToOrder,
        deleteTool,
      }}
    >
      {children}
    </LoanContext.Provider>
  );
};

export const useLoanContext = () => {
  const context = useContext(LoanContext);
  if (context === undefined) {
    throw new Error("useLoanContext must be used within a LoanProvider");
  }
  return context;
};
