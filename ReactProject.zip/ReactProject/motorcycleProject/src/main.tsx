import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { BrowserRouter } from 'react-router-dom'
import { LoanProvider } from './context/loanContext.tsx'

createRoot(document.getElementById('root')!).render(
  <BrowserRouter>
    <LoanProvider>
      <App />
    </LoanProvider>    
  </BrowserRouter>,
)
