<?php $__env->startSection('content'); ?>

    <div class="container my-5">
        <div class="row">
            <!-- Felhasználói adatlap szakasz -->
            <div class="col-12 col-md-6 mb-4 mb-md-0 pt-5">
                <div class="user-profile-container position-relative">
                    <!-- Gomb a jobb felső sarokban (csak nagyobb képernyőn) -->
                    <div class="d-none d-md-block position-absolute top-0 end-0 mt-2 me-2">
                        <button type="button" id="EditBtn" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#editUserModal">
                            Adatok módosítása
                        </button>
                    </div>

                    <h1 class="profile-header"><strong>Felhasználói Adatlap</strong></h1>

                    <div class="user-data-section">
                        <h2 class="section-title">Felhasználó adatai:</h2>
                        <br>
                        <ul class="user-info-list">
                            <li class="info-item"><strong>Név: </strong> <?php echo e(auth()->user()->name); ?></li>
                            <li class="info-item"><strong>Azonosító: </strong> <?php echo e(auth()->user()->id); ?></li>
                            <li class="info-item"><strong>Email cím: </strong> <?php echo e(auth()->user()->email); ?></li>
                            <li class="info-item"><strong>Telefonszám: </strong> +<?php echo e(auth()->user()->phoneNumber); ?></li>
                        </ul>
                    </div>

                    <div class="license-images-section pe-5">
                        <h2 class="section-title ps-3">Jogosítvány:</h2>
                        <div class="image-container">
                            <img src="<?php echo e(asset('storage/' . auth()->user()->drivingLicenceImage)); ?>" alt="Driving Licence"
                                class="license-image img-fluid">
                            <img src="<?php echo e(asset('storage/' . auth()->user()->drivingLicenceImageBack)); ?>"
                                alt="Jogosítvány hátsó oldala" class="license-image img-fluid">
                        </div>
                    </div>

                    <div class="d-md-none text-center mt-3">
                        <button type="button" id="EditBtn" class="btn btn-primary w-100" data-bs-toggle="modal"
                            data-bs-target="#editUserModal">
                            Adatok módosítása
                        </button>
                    </div>
                </div>
            </div>


            <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editUserModalLabel">Felhasználói adatok módosítása</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Bezárás"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('updateUserData')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Név</label>
                                    <input type="text" class="form-control" id="name" name="name"
                                        value="<?php echo e(auth()->user()->name); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email cím</label>
                                    <input type="email" class="form-control" id="email" name="email"
                                        value="<?php echo e(auth()->user()->email); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phoneNumber" class="form-label">Telefonszám</label>
                                    <input type="text" class="form-control" id="phoneNumber" name="phoneNumber"
                                        value="<?php echo e(auth()->user()->phoneNumber); ?>" required>
                                </div>

                                <div class="mb-3 text-center">
                                    <label for="drivingLicenceImage" class="form-label">Jogosítvány (elöl)</label>
                                    <input type="file" class="form-control" id="drivingLicenceImage"
                                        name="drivingLicenceImage" accept="image/*"
                                        onchange="previewImage(event, 'previewFront')">
                                    <div class="d-flex justify-content-center mt-2">
                                        <img id="previewFront"
                                            src="<?php echo e(asset('storage/' . auth()->user()->drivingLicenceImage)); ?>"
                                            alt="Jogosítvány elöl" class="img-fluid rounded shadow" width="150">
                                    </div>
                                </div>

                                <div class="mb-3 text-center">
                                    <label for="drivingLicenceImageBack" class="form-label">Jogosítvány (hátul)</label>
                                    <input type="file" class="form-control" id="drivingLicenceImageBack"
                                        name="drivingLicenceImageBack" accept="image/*"
                                        onchange="previewImage(event, 'previewBack')">
                                    <div class="d-flex justify-content-center mt-2">
                                        <img id="previewBack"
                                            src="<?php echo e(asset('storage/' . auth()->user()->drivingLicenceImageBack)); ?>"
                                            alt="Jogosítvány hátul" class="img-fluid rounded shadow" width="150">
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-success w-100">Mentés</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-4 mb-4">
                <div class="menu-container my-5 rounded-2 bg-gray-300">
                    <div class="row">
                        <?php if(count($loans) > 0): ?>
                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 mb-4">
                                    <div class="card shadow-sm rounded h-auto position-relative">
                                        <div class="card-header bg-red-900 text-white">
                                            <div class="d-flex justify-content-between">
                                                <h5 class="fs-6 fs-md-5">Rendelési azonosító: <?php echo e($loan['orders_id']); ?></h5>
                                                <span class="text-muted-primary fs-6"><?php echo e($loan['rental_period']['rentalDate']); ?> -
                                                    <?php echo e($loan['rental_period']['returnDate']); ?></span>
                                            </div>
                                        </div>
                                        <!-- Törlés gomb -->
                                        <div class="position-absolute bottom-0 end-0">
                                            <form class="delete-order-form" method="POST"
                                                action="<?php echo e(route('deleteOrder', $loan['orders_id'])); ?>"
                                                data-rental-date="<?php echo e(\Carbon\Carbon::parse($loan['rental_period']['rentalDate'])->toIso8601String()); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" class="delete-btn btn" data-bs-toggle="modal"
                                                    data-bs-target="#deleteModal<?php echo e($loan['orders_id']); ?>"
                                                    style="margin-left: 10px;">
                                                    <i class="bi bi-trash text-danger" style="font-size: 1.5rem;"></i>
                                                </button>
                                            </form>
                                        </div>

                                        <div class="card-body">
                                            <h5 class="mb-0"><strong>Motor:</strong> <?php echo e($loan['motorcycle']['brand']); ?>

                                                <?php echo e($loan['motorcycle']['type']); ?></h5>

                                            <div class="mt-3">
                                                <?php if(count($loan['tools']) > 0): ?>
                                                    <h6 class="text-success">Kapcsolt eszközök:</h6>
                                                    <ul class="list-unstyled">
                                                        <?php $__currentLoopData = $loan['tools']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li>
                                                                <i class="bi bi-tools me-2 text-secondary"></i>
                                                                <strong><?php echo e($tool['tool_name']); ?> (<?php echo e($tool['tool_size']); ?>)</strong> -
                                                                Kapcsolva: <?php echo e($tool['connected_at']); ?>

                                                                <form class="delete-tool-form" action="<?php echo e(route('deleteTool', $tool['tool_id'])); ?>" method="POST"
                                                                    style="display:inline;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit"
                                                                        class="btn btn-danger delete-tool-btn btn-sm ms-2">
                                                                        <i class="bi bi-trash"></i> Törlés
                                                                    </button>
                                                                </form>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php else: ?>
                                                    <p class="text-muted">Nincsenek kapcsolt eszközök.</p>
                                                <?php endif; ?>
                                                <form class="add-tool-form" action="<?php echo e(route('addToolToOrder', $loan['orders_id'])); ?>" method="POST"
                                                    style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" class="btn btn-success add-tool-btn btn-sm" data-bs-toggle="modal"
                                                        data-bs-target="#addToolModal<?php echo e($loan['orders_id']); ?>">
                                                        Új eszköz hozzáadása
                                                    </button>
                                                </form>
                                            </div>
                                        </div>



                                    </div>
                                </div>


                                <!-- Törlés megerősítő ablak -->
                                <div class="modal fade" id="deleteModal<?php echo e($loan['orders_id']); ?>" tabindex="-1"
                                    aria-labelledby="deleteModalLabel<?php echo e($loan['orders_id']); ?>" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered w-100" style="max-width: 600px;">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="deleteModalLabel<?php echo e($loan['orders_id']); ?>">Rendelés
                                                    törlése</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Biztosan törölni akarja ezt a rendelést? Ez a művelet nem visszavonható.
                                            </div>
                                            <div class="modal-footer d-flex justify-content-between w-100">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Mégse</button>
                                                <!-- A form az 'action' és a 'DELETE' metódus most itt megerősíti a törlést -->
                                                <form method="POST" action="<?php echo e(route('deleteOrder', $loan['orders_id'])); ?>"
                                                    style="display:inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger w-100 w-sm-auto">Törlés
                                                        megerősítése</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <!-- Tool Hozzáadás Ablak -->
                                <div class="modal fade" id="addToolModal<?php echo e($loan['orders_id']); ?>" tabindex="-1"
                                    aria-labelledby="addToolModalLabel<?php echo e($loan['orders_id']); ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form action="<?php echo e(route('addToolToOrder', $loan['orders_id'])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="addToolModalLabel<?php echo e($loan['orders_id']); ?>">Eszköz
                                                        hozzáadása rendeléshez</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Bezárás"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <label for="tool_id" class="form-label">Válassz eszközt</label>
                                                        <select class="form-select" name="tool_id" required>
                                                            <option value="" disabled selected>-- Válassz egy eszközt --</option>
                                                            <?php $__currentLoopData = $availableTools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tool->id); ?>"><?php echo e($tool->toolName); ?>

                                                                    (<?php echo e($tool->size); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <p class="text-danger text-center">Egy típusú eszközből maximum 2db-ot lehet
                                                    kölcsönözni!</p>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">Hozzáadás</button>
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Mégse</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="col-12">
                                <p class="text-center text-muted">Nincs még rendelés.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Bai Máté\Desktop\Projekt_feladat-main\Projekt_feladat-main\resources\views/userProfile.blade.php ENDPATH**/ ?>