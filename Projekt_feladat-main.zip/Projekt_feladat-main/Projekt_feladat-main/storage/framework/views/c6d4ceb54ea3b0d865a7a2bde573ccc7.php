<?php echo e($slot); ?>

<?php /**PATH C:\Users\Bai Máté\Desktop\Projekt_feladat-main\Projekt_feladat-main\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>