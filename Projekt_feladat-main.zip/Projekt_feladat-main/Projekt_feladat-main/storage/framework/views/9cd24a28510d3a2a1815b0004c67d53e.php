<?php $__env->startSection('content'); ?>
<body style="background-image: url('/storage/img/Hatter.jpg'); background-size: cover; background-position: center; background-repeat: no-repeat;"></body>
    <div class="container mt-4" >
        <div class="row justify-content-center">
            <div class="col-12 col-sm-10 col-md-8 col-lg-6">
                <div class="card" style="height: 100%">
                    <div class="card-header text-center bg-primary text-white" id="regist-login-Header"><?php echo e(__('Bejelentkezés')); ?></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <div class="form-floating">
                                    <input placeholder="" id="floatingInput" type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                        value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                    <label for="floatingInput"><?php echo e(__('Email cím')); ?></label>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="mb-3">
                                <div class="form-floating">
                                    <input placeholder="" id="password" type="password"
                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                        required autocomplete="current-password">
                                    <label for="password"><?php echo e(__('Jelszó')); ?></label>

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-12 d-flex justify-content-between">
                                    <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link text-dark" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Elfelejtett jelszó')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row mb-0">
                                <div class="col-12 text-center">
                                    <button type="submit" id="LoginBtn" class="btn btn-white-100 border-3 border-dark w-40"><?php echo e(__('Bejelentkezés')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Bai Máté\Desktop\Projekt_feladat-main\Projekt_feladat-main\resources\views\auth\login.blade.php ENDPATH**/ ?>