<x-mail::message>
Hello!
Az alábbi gomb megnyomásával erősítheted meg az email címedet:

<x-mail::button :url="$actionUrl">
{{ $actionText }}
</x-mail::button>

Köszönjük hogy tagja lehetsz a csapatnak!<br>
MotorKirályok csapata.
</x-mail::message>